#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
gateway="${repo_root}/build/gateway/b2_policy_controller"
test -x "${gateway}" || {
  echo "Run scripts/build_sim_stack.sh first." >&2
  exit 1
}
exec env LD_LIBRARY_PATH="/home/zhangchi/.local/unitree-sdk2-21d0a3b/lib" "${gateway}" --sim
