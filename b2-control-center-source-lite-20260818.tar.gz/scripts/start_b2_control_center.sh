#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python_bin="${repo_root}/.worktrees/offline-policy-foundation/.venv/bin/python"
lock_file="${XDG_RUNTIME_DIR:-/tmp}/b2-control-center-${UID}.lock"

test -x "${python_bin}" || {
  echo "B2 Control Center Python environment is missing: ${python_bin}" >&2
  exit 1
}

exec 9>"${lock_file}"
if ! flock -n 9; then
  echo "B2 Control Center is already running."
  exit 1
fi

cd "${repo_root}"
exec "${python_bin}" -m b2_control.cli_control_center "$@"
