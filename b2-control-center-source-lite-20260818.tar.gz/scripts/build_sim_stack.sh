#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
sdk_prefix="/home/zhangchi/.local/unitree-sdk2-21d0a3b"
deps_prefix="/home/zhangchi/.local/b2-deps/usr"
mujoco_prefix="/home/zhangchi/unitree_official/mujoco-3.3.6"
build_dir="${repo_root}/build/gateway"
sim_dir="${repo_root}/third_party/unitree_mujoco/simulate"

test -f "${sdk_prefix}/lib/cmake/unitree_sdk2/unitree_sdk2Config.cmake" || {
  echo "Missing pinned Unitree SDK install: ${sdk_prefix}" >&2
  exit 1
}
test -f "${mujoco_prefix}/lib/libmujoco.so.3.3.6" || {
  echo "Missing pinned MuJoCo install: ${mujoco_prefix}" >&2
  exit 1
}

if ! test -e "${sim_dir}/mujoco"; then
  cmake -E create_symlink "${mujoco_prefix}" "${sim_dir}/mujoco"
fi
cmake -S "${sim_dir}" -B "${sim_dir}/build" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH="${sdk_prefix};${deps_prefix}" \
  -DBOOST_ROOT="${deps_prefix}" -DBoost_NO_SYSTEM_PATHS=ON \
  -DCMAKE_CXX_FLAGS="-I${deps_prefix}/include" \
  -DCMAKE_EXE_LINKER_FLAGS="-L${deps_prefix}/lib/x86_64-linux-gnu -Wl,-rpath,${deps_prefix}/lib/x86_64-linux-gnu"
cmake --build "${sim_dir}/build" --target unitree_mujoco -j2

cmake -S "${repo_root}/gateway" -B "${build_dir}" \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="${sdk_prefix}"
cmake --build "${build_dir}" -j2
echo "Built official B2 MuJoCo and all gateway/probe targets"
