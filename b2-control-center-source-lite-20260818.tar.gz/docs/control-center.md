# B2 Sim2Real Control Center 使用说明

这是一个不依赖 Codex 的本机控制程序。它统一管理经过校验的 ONNX policy、官方
Unitree DDS MuJoCo、LowState→policy→LowCmd 链路、键盘操作台、真机只读检查、
原生/自研 locomotion 切换、会话日志、录像和关节跟踪统计。

## 启动

双击桌面的 **B2 Control Center**。也可以在终端运行：

```bash
/home/zhangchi/b2_control_stack/scripts/start_b2_control_center.sh
```

程序只监听 `127.0.0.1`，每次启动使用随机 URL token。页面打开时状态为 `IDLE`，
不会连接真机、不会释放原生 locomotion、不会发布 LowCmd，也不会自动行走。一个
用户会话只允许启动一个控制中心实例。

## 仿真

1. 选择已经通过 manifest、文件 SHA-256 和 45→12 接口检查的 policy。
2. 选择地形，设置 W/S、A/D 和 Q/E 的命令幅值。
3. 点击“一键启动仿真、DDS gateway、Policy 与录像”。
4. 状态变为 `SIMULATION` 后，在下方实时操作台控制。
5. 点击“停止并保存录像”，等待状态回到 `IDLE`。

“自动仿真测试模板”不是参数预填按钮。站立10秒、平地不同速度前进2秒和楼梯4秒
模板会在确认后启动对应仿真、等待操作台允许命令、按限定时间运行、强制回到零命令，
随后停止会话并封装录像、CSV和独立JSON结果。模板后端只接受 `SIMULATION` 且
`lo / DDS domain 1` 会话；真机连接或启动期间会直接拒绝。

仿真固定使用 DDS domain 1 和 loopback 网卡；真机使用 domain 0 和选择的物理网卡，
二者不能互相发现。每次仿真强制录像，并为 simulator、policy 和 gateway 分别保存
日志与 CSV。

| 场景 | 用途 |
|---|---|
| 标准平地 | 基础回归 |
| 草地近似 | 高摩擦、软接触和毫米级起伏 |
| 泥路近似 | 低摩擦、软接触和打滑敏感性 |
| 石子路 | 78 个固定随机种子的低矮石块 |
| 10/15/20 cm 楼梯 | 不同难度的台阶测试 |
| 12° 斜坡 | 连续坡面与顶部平台 |
| 综合地形 | 草地、泥路、石块和 10 cm 台阶组合 |

草地和泥路使用 MuJoCo 的 `friction`、`solref`、`solimp` 做工程近似，并不是对某一
现场土壤的标定。所有场景使用官方 B2 模型和 0.002 s 仿真步长。

## 实时操作台

- 1–9：选择 W/S 的 0.1–0.9 m/s 档位；不会单独触发运动。
- W/S：按当前档位前进/后退，松开清零 `vx`。
- A/D：按住左移/右移，松开清零 `vy`。
- Q/E：每按一次将 `wz` 增加/减少 0.10 rad/s（界面可配置步长）。
- Space/X/Esc：清零速度并继续 learned hold，不会直接切成 `Q_DEFAULT`。
- 原生 locomotion：先清零、检查关节静止，再正常归还官方 `ai`。
- 自研 locomotion：真机模式下必须再次确认，随后才执行 MotionSwitcher 和低层接管。

操作台显示实时命令方向、50 Hz ONNX 推理时间、LowState 序号，以及 12 个关节的
q_target、q_actual、误差、dq、tau_est、温度和通信丢失计数；同时显示电池 SOC、BMS
原始电流值、最大电机温度/估算力矩和安全锁存状态。
会话在线时，主控制中心和嵌入操作台均可接收运动键；焦点位于输入框或下拉框
时不会转发。浏览器失焦、页面隐藏或按键松开都会释放正在按住的平移键。

真机连接前可以把“运动命令源”切换成宇树手持遥控器：A 进入 policy、R2 回
learned hold、L2+B 锁存 `SAFE_DAMPING`。此时实时操作台继续显示遥控器命令和
状态，但网页 W/S/A/D/Q/E 会被禁用，保证每个会话只有一个运动命令源。遥控器专项
安全流程见 [hand-remote-onnx-policy.md](./hand-remote-onnx-policy.md)。仿真控制中心
使用网页键盘；遥控消息回放仍使用已有的独立仿真测试脚本。

## 一键连接真机

“一键连接机器狗”是明确的两段式流程：

1. 选择连接 B2 的物理网卡并确认。控制台先读取该接口的操作状态；只有明确为
   `UP` 才允许点击连接。若网线未接或接口为 `DOWN`，后端会在创建真机会话、启动
   相机或执行任何 MotionSwitcher/DDS probe 之前同步拒绝，并明确提示“物理链路未
   连接/网卡 DOWN”。链路为 `UP` 后，程序首先只读 MotionSwitcher，必须确认当前为
   官方 `name=ai`；没有这项确认就不会继续 LowCmd 检查或启动 Policy 控制台。
2. 随后用显式 `--expect-native-lowcmd` 模式按完整3秒窗口读取
   `rt/lowstate` 和 `rt/lowcmd`。B2 原生 `ai` 约500 Hz的 LowCmd 是正常基线，
   不再要求 `lowcmd_samples=0`。`ai` 刚恢复时可能暂时为零/低频；此时控制台
   会明确显示“原生恢复中”，最多重试5个完整3秒窗口（总计15秒）。最终必须
   获得一个 LowState CRC/finite 正常、LowCmd总观测速率在350–650 Hz的完整
   稳定窗口，并明确返回 `lowcmd_policy=native_500hz`、
   `lowcmd_native_rate_ok=1`、`lowcmd_publisher_conflict=0`。持续零/低频在15秒后
   拒绝；高于650 Hz、CRC/invalid 非零或稳定窗口的其他异常立即拒绝，不重试。
   `lowcmd_publisher_conflict` 在该探测器中是总速率包络判定，不是 DDS writer
   来源确证；通过只表示未发现速率异常。每个失败/成功窗口的完整输出都会
   追加到 `readonly-lowstate.log`。
   本机遗留的自研 gateway/orphan 进程也会在进入只读流程前直接阻止连接。
3. 只读检查成功后状态为 `HARDWARE_CONNECTED`，此时机器人仍由官方 locomotion
   控制。只有再次点击下方“自研 locomotion”并确认，才允许启动 gateway、释放
   `ai` 并进入自研 LowCmd 链路。

控制台还会只读扫描本机已运行的 ROS 2 domain 0 participant。这类进程（例如
`ros2-daemon`）可能在多网卡主机上产生跨接口 DDS discovery 噪声；页面和会话日志
会显示 PID/提示，但不会自动 kill、收养或改动这些进程，也不会因提示本身绕过
上述稳定窗口门禁。

页面的 Hardware Operation Readiness 会显示连接后的能力状态。进入
`HARDWARE_CONNECTED` 后，实时操作台、原生 B2 动作和键盘/遥控器切换自动变为
`AVAILABLE`；不需要再勾选或手动启用控制按钮。自研 locomotion 和 Policy 运动命令
只有在所选安全配置与 Policy 审批匹配时才显示 `AVAILABLE`，否则保持 `LOCKED` 并
列出具体原因。

“连接”不是“行走”。接管后仍从 learned hold 和零速度开始；网页模式必须由现场
人员明确按住 W/S/A/D，遥控模式必须摇杆居中按 A 后再推动摇杆，才产生速度命令。
每次真机测试仍应有吊架/防跌落、物理急停、现场保护人员和通畅落脚区域。

控制中心把“官方原生 locomotion”和“自研低层/仿真”放在两个互斥页面。原生页只
调用官方高层动作，包含停止、站起、趴下、恢复站立、恢复 `ai` 和有边界的
`Move(vx, vy, wz)`；自研页才显示 Policy、仿真模板、激活门和低层操作台。切换页面
本身不会切换控制权；在原生页按 W/S/A/D 也不会向嵌入的自研操作台转发按键。

连接真机时会用一个汇总确认框确认操作者在场、测试区域清空、机型/固件已核对、
物理急停可用，以及当前命令源为零；页面不再显示逐项打钩框。自研接管还有一层
独立的参数审批门。控制台可以在
`configs/b2-reference-profile.json` 和 `configs/hardware-profiles/*.json` 中发现并选择
多套配置，不再固定绑定单一文件；当前会话选中的文件路径和摘要会传入 C++ gateway。
新建页面或刷新时，如果操作员尚未显式选择配置，控制台会优先显示第一个对当前
Policy 哈希实际通过 `policy_approvals` 的配置；如果没有任何通过项，才回退到
安全的 reference/`LOCKED` 显示。操作员的显式选择不会被后续状态刷新覆盖；这只是
默认显示规则，不会连接真机或绕过激活审批。
每套配置仍分别要求状态为 `approved`、明确允许激活、策略文件 SHA-256 与审批记录
完全一致，并填写机身序列号、固件版本、复核人和时间。仓库随附的参考文件是
`reference_only` 且字段为空，因此默认会拒绝真机自研接管；不能用参考值冒充已经
完成的实机标定。

真机 gateway 在释放官方 `ai` 前检查本机文件锁、遗留自研 gateway，以及 DDS
`rt/lowcmd` 总速率是否偏离官方原生基线。原生 `name=ai` 对应的约 500 Hz
LowCmd 不作为速率异常；本机 orphan 仍会直接阻止接管。总速率检查不能单独
确证 DDS writer 来源。接管后使用审批过的逐关节
Kp/Kd、增益爬坡、目标变化率、软/硬角度边界，
并持续监控 LowState CRC/NaN/超时、policy/命令超时、发布心跳、关节速度、估算力矩、
持续跟踪误差、电机温度/通信 lost、机身倾角/角速度，以及 BMS 的 SOC、原始电流值
和温度。任一保护触发后锁存 `SAFE_DAMPING`：12 关节 Kp/tau 归零，只保留审批的
阻尼 Kd，且不会自动归还原生 locomotion。

每个真机会话连续写入 gateway CSV；故障另写 `gateway.csv.fault.json`，记录首个故障
原因、配置/策略摘要和恢复要求。500 Hz 进程内 watchdog 能覆盖控制线程停滞，但不能
覆盖整个进程、主机或供电彻底失效，所以物理急停和机械防跌落仍不可替代。当前 B2
LowState 不提供逐电机电流，程序监控 tau_est 和 BMS 总电流原始值；审批文件中的
逐关节 `current_limit` 是预留审查项，不能宣称已经形成逐电机电流闭环保护。

故障黑匣子保留故障前30秒与故障后30秒。故障恢复必须先看到
`gateway.csv.blackbox.complete.json` 且状态为 `complete`；否则控制中心会根据故障
单调时钟显示预计剩余时间并拒绝结束 SAFE_DAMPING gateway，避免恢复动作截断后窗口。
嵌入操作台一旦报告 `FAULT/DAMPING`，外层会话也会锁存为同一个
真机故障会话；完成标记出现后恢复按钮才会开放。若 gateway 已退出且只读
MotionSwitcher 已确认原生 `ai`，策略控制台因历史故障保留的非零退出码不会再
覆盖当前 `NATIVE` 状态。

若系统存在 `/dev/video0` 且安装了 GStreamer，真机只读会话创建时会同时录制
`hardware-camera.webm`，退出时用 SIGINT 正常封装。没有相机只会在能力状态显示
`UNAVAILABLE`，不会导致连接失败。仿真仍使用已有的 MP4 录像链路。

断开时使用“断开 / 归还原生 locomotion”。程序会先让命令归零并调用现有安全退出
逻辑；真机会话不会用 `SIGKILL` 强行终止低层控制进程。

键盘/遥控器命令源只能在已验证且仍由原生 locomotion 控制的状态切换，切换前会先
清零命令。页面还提供原生 B2 的站立、起身、趴下、恢复站立、阻尼和低功耗操作；
这些按钮只在 `HARDWARE_CONNECTED` 可用，危险动作需要额外确认，并拒绝在自研
LowCmd 已接管时执行。

`FAULT` 是锁存状态。恢复按钮要求现场人员确认机器人已支撑、物理急停可用并检查过
故障证据；程序只会向记录且核对过命令行的 gateway PID 发送 `SIGTERM`，不使用
`SIGKILL`。gateway 正常退出后才显式请求恢复官方 `ai`；任何一步失败都继续保持
`FAULT`，不会自动重试或自动运动。

## Policy 管理与后续扩展

点击“校验并添加”，选择包含 `manifest.json` 的 bundle 目录。注册表保存在：

```text
~/.config/b2-control-center/policies.json
```

每次启动前都会重新校验 manifest 和 policy 文件 SHA-256。当前运行适配器为
`b2_45x12_v1`，要求 float32、45 维 observation、12 维 action、50 Hz policy。
注册表已经把 policy bundle、显示名和 adapter 分离；以后接入不同 observation、
关节数量或推理频率的 policy 时，应新增 adapter，而不是在现有 45→12 路径里写
模型特例。接口不匹配或文件被改动的 policy 会显示为不可用并拒绝启动。

## 日志、录像和图表

控制中心页面底部的文件名可以直接点击查看。文件位于：

```text
/home/zhangchi/b2_control_stack/logs/control-center/<session-id>/
/home/zhangchi/b2_control_stack/logs/videos/
```

有运动样本的会话停止后会自动生成：

- `policy-tracking-tracking.svg`：12 关节 q_target 与 q_actual；
- `policy-tracking-raw-action.svg`：ONNX raw action 与实际采用 action；
- `policy-tracking-stats.csv`：p2p、actual/target、MAE、RMSE、最大误差和 clip 比例；
- `policy-tracking-summary.md`：便于直接阅读的统计表。

录像只有在停止流程完成、页面回到 `IDLE` 后才完成封装；不要直接关闭仿真窗口。
控制中心会先冻结/结束 MuJoCo 画面，同时保持 policy 命令在线，再正常停止 gateway，
最后停止 policy，避免把正常关机误判为 policy timeout 或在录像末尾失去承重。

## 状态与故障处理

页面同时显示进程状态和独立的真机生命周期：`DISCONNECTED → READ_ONLY_CHECK →
NATIVE_CONFIRMED → ARMED → CUSTOM_INTERPOLATION → HOLD → WALK → STOPPING →
NATIVE/FAULT`。进程状态用于启动与停止管理；真机生命周期用于说明当前控制权和低层
输出，不能用一个笼统的“已连接”代替。

| 状态 | 含义 |
|---|---|
| IDLE | 无仿真、无真机连接 |
| SIM_STARTING | 正在启动仿真、policy 和 gateway |
| SIMULATION | 全链路在线 |
| HARDWARE_CONNECTING | 仅做 LowState/CRC/MotionSwitcher 检查 |
| HARDWARE_CONNECTED | 只读连接成功，默认仍为原生模式 |
| STOPPING | 正常停止、归还或封装录像 |
| FAULT | 启动或退出失败；事件日志保留具体原因 |

常见问题：

- 网卡显示 `down`：检查网线和接口，不要选择 Wi-Fi 或 loopback。
- policy 不可用：检查 bundle 的 manifest、ONNX 文件和 SHA-256 是否仍一致。
- 仿真没有出现操作台：查看当前 session 的 `simulator.log`、`policy.log`、
  `gateway.log`；只有三个阶段全部通过才进入 `SIMULATION`。
- 没有生成统计图：该会话只有 learned hold、没有 motion 样本；CSV 和录像仍保留。
- 页面关闭：控制进程仍由启动终端管理；回到启动终端按 Ctrl-C 才会执行正常退出。
- 异常重启：启动时会扫描仍存活的 `--hardware` gateway，并在状态快照和页面顶端告警；
  控制中心不会收养、终止或自动恢复该进程，也绝不会恢复上次自研状态。
- 真机激活显示 `LOCKED`：打开规范配置文件查看缺失审批项；不要直接删除门禁。
- `SAFE_DAMPING`：先物理支撑机器人并检查 gateway CSV/故障 JSON，再使用锁存恢复流程。

## 设计依据

- [Unitree 官方 unitree_mujoco](https://github.com/unitreerobotics/unitree_mujoco)：
  仿真 DDS domain 1 + `lo`、LowCmd/LowState 和场景加载方式。
- [Unitree SDK2 官方低层示例](https://github.com/unitreerobotics/unitree_sdk2/blob/main/example/go2/go2_stand_example.cpp)：
  MotionSwitcher、LowCmd 初始化、`rt/lowcmd`、`rt/lowstate` 和 CRC。
- [Unitree 官方 B2 部署入口](https://github.com/unitreerobotics/unitree_rl_lab/blob/main/deploy/robots/b2/main.cpp)：
  启动前确认 MotionSwitcher 所有权，并避免自研低层发布者与异常额外发布者并行运行；
  官方 `name=ai` 状态下的原生 LowCmd 是基线，不应仅因存在样本就误判为冲突。
- [MuJoCo MJCF Reference](https://mujoco.readthedocs.io/en/stable/XMLreference.html)：
  geom friction、软接触参数、height field 和静态地形定义。
