# B2 0.25 m/s sim-to-real dry-run comparison

Date: 2026-08-11  
Joint order: `FR, FL, RR, RL` with `hip, thigh, calf` inside each leg.

Both paths used the same verified ONNX actor, observation implementation, and
`0.25 m/s` forward command. The simulator used the official Unitree B2 MuJoCo
bridge on DDS domain 1 and loopback. The hardware path subscribed to real
LowState on domain 0 while native `ai_sport` retained control and published no
LowCmd.

## Aggregate differences

| Signal | RMSE | Maximum absolute difference |
|---|---:|---:|
| measured joint position | `0.1487 rad` | `0.3010 rad` |
| raw actor action | `0.3980` | `0.9481` |
| candidate joint target | `0.0688 rad` | `0.1440 rad` |

## Per-joint simulator minus hardware

| Joint | Measured q | Raw action | Candidate target |
|---|---:|---:|---:|
| FR hip | -0.0775 | 0.9481 | 0.1185 |
| FR thigh | 0.1581 | 0.1960 | 0.0491 |
| FR calf | -0.0724 | 0.0269 | 0.0068 |
| FL hip | 0.0694 | -0.5532 | -0.0691 |
| FL thigh | 0.1621 | -0.1980 | -0.0495 |
| FL calf | -0.0606 | -0.1634 | -0.0409 |
| RR hip | -0.1166 | 0.3311 | 0.0414 |
| RR thigh | 0.3010 | -0.0600 | -0.0150 |
| RR calf | 0.0305 | -0.3221 | -0.0806 |
| RL hip | 0.0573 | -0.0934 | -0.0117 |
| RL thigh | 0.2927 | -0.1829 | -0.0457 |
| RL calf | -0.0088 | -0.5761 | -0.1440 |

## Interpretation boundary

The simulator sample is the final frame of a 10-second learned-policy walking
run. The hardware sample is a native-controller standing frame; the learned
policy did not own real actuators. Consequently these samples are not gait
phase aligned and cannot select either fault branch from the handoff guidance:

- they do not show that identical learned-policy joint output moves simulation
  but fails to move hardware;
- they do not show a deployment-code mismatch, because the same Python policy
  implementation produced both candidate outputs from different robot states.

The result establishes a reproducible baseline and identifies the largest
state difference at RR thigh and the largest candidate-target difference at RL
calf. A conclusive comparison requires the reviewed hardware adapter, smooth
target acquisition, and synchronized logging after both simulator and hardware
are controlled by the learned policy. Abruptly applying the sampled hardware
candidate remains blocked by the separately measured `0.378 rad` posture gap.
