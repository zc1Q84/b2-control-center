# B2 手持遥控器接入自研 ONNX policy

## 遥控语义（保持宇树原键位）

| 输入 | 自研 policy 行为 |
|---|---|
| 左摇杆前后 `ly` | `vx = ly × 0.90 m/s` |
| 左摇杆左右 `lx` | `vy = -lx × 0.25 m/s` |
| 右摇杆左右 `rx` | `wz = -rx × 0.40 rad/s` |
| `A` | 从 learned hold 切到运动 policy；按下时摇杆必须居中 |
| `R2` | 回到 learned hold/站立，不退出低层控制 |
| `L2+B` | 软件急停并锁存 `SAFE_DAMPING` |

其它键没有重新分配。摇杆死区默认 `0.10`。遥控模式至少执行 5 秒 learned-hold
启动窗口，覆盖 3 秒 LowState→policy hold target 平滑交接；启动窗口内不会响应 A
进入运动，但 L2+B 始终由 C++ gateway 直接检测。

急停输出为 12 关节 `Kp=0、Kd=3、tau=0`。急停松键不会恢复，gateway 也不会自动
切回 `ai`；急停后先让现场人员固定/支撑机器人，保持 gateway 持续输出阻尼，确认
安全后才能退出全部自研进程并重新走接管流程。
这是软件保护，不代替物理急停、吊架或现场保护人员。

## 真机使用

上机前让遥控器开机、摇杆居中，机器人保持官方站立。第一个终端启动 gateway：

```bash
cd /home/zhangchi/b2_control_stack
env LD_LIBRARY_PATH=/home/zhangchi/.local/unitree-sdk2-21d0a3b/lib \
  build/gateway/b2_policy_controller \
  --hardware enp8s0 --acknowledge-b2-low-level-control \
  --diagnostics-csv logs/remote-hardware-gateway.csv
```

第二个终端启动 policy：

```bash
/home/zhangchi/.local/bin/b2-policy-teleop \
  '/home/zhangchi/文档/xwechat_files/wxid_zyi9sp7uwkvz22_2442/msg/file/2026-08/b2_policy_deployment_handoff(1)/b2_policy_deployment_handoff' \
  --remote-control \
  --diagnostics-csv /home/zhangchi/b2_control_stack/logs/remote-hardware-policy.csv
```

看到 gateway 进入 `POLICY` 且 5 秒启动窗口结束后，保持摇杆居中短按 A，再缓慢推
左摇杆。R2 回站立。L2+B 是锁存急停。

## 已完成验证

- 真机只读：`rt/lowstate` 约 500 Hz，CRC/NaN 错误为 0；当前 EDU 固件不发布独立
  `rt/wirelesscontroller`，所以 gateway 按宇树官方低层示例解析
  `LowState.wireless_remote[40]`，实测头为 `0x55 0x51`、居中轴为 0。
- 仿真全链：`A→ONNX policy→LowCmd`、约 0.25 m/s、`R2→learned hold`、
  `L2+B→SAFE_DAMPING(Kd=3)` 全部通过。
- 录像：`logs/videos/remote-onnx-estop-sim-20260812.mp4`。
