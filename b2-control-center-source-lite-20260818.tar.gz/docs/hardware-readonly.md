# B2 hardware read-only gate

Public, training, and still-unapproved parameters are classified separately in
[`b2-parameter-research.md`](b2-parameter-research.md). Do not copy an official
demo or simulator value into a real-hardware profile without hardware-owner
review.

This gate sends no DDS command and creates no publisher. It only subscribes to
the official B2 `rt/lowstate` topic on DDS domain 0, then checks receive rate,
the official CRC, finite joint samples, and IMU quaternion norm.

1. Keep the robot supported and do not start a low-level controller.
2. Connect the dedicated robot Ethernet cable.
3. Find the wired interface with `ip -brief link`; do not use `lo`, Wi-Fi, or a
   guessed interface.
4. Build once with `scripts/build_sim_stack.sh`.
5. Run, replacing `ROBOT_IFACE` with the exact wired interface:

```bash
scripts/run_hw_probe.sh ROBOT_IFACE 10
```

The final line must be `PASS`, with both `crc_errors=0` and
`invalid_samples=0`. Save the complete output for the engineering review. A
failure or zero samples blocks every later actuator test; it is not permission
to change the robot's native software.

## Policy dry-run

The probe also mirrors every tenth valid state packet to localhost for a
read-only 50 Hz policy dry-run. Start the dry-run first, then start the probe in
a second terminal. The dry-run process has no `LowCmd` publisher.

```bash
env PYTHONPATH=src \
  /home/zhangchi/b2_control_stack/.worktrees/offline-policy-foundation/.venv/bin/python \
  -m b2_control.cli_hw_dryrun POLICY_BUNDLE --duration 10 --speed 0.25
```

Use `--hold` for the required zero-command standing check before evaluating a
moving command.

```bash
scripts/run_hw_probe.sh ROBOT_IFACE 12
```

A dry-run `PASS` confirms only that real state can be transformed and inferred
without invalid numbers. It does not approve motor enable.

On the connected B2, the first crouched-state dry-run measured a maximum
current-to-policy target difference of `1.770 rad`. Direct policy enable from
that posture is blocked. Native locomotion must first establish a stable stand,
and the reviewed handover must enforce continuity and target slew limits.

After native locomotion established a stable stand, the 0.25 m/s dry-run
reduced that difference to `0.377 rad`; zero-command hold measured `0.388 rad`.
The native and learned standing postures therefore remain materially different.
Both abrupt moving-policy and hold-policy handovers are blocked until the
hardware-owned adapter applies reviewed per-joint continuity, slew, gain, and
limit rules. The sampled hold target retained `0.6764 rad` minimum margin to
the official model hard joint ranges, so the observed blocker is handover
continuity rather than a hard-range violation.

The level-standing IMU check decoded the real quaternion as `wxyz` and produced
projected gravity `[0.00075, 0.01466, -0.99989]`, consistent with the required
`[0, 0, -1]`. This validates the level orientation mapping; controlled positive
roll and pitch fixture checks are still required before actuator commissioning.

The operator-confirmed native mapping is `L2+B` for damping. It has priority
over the planned `B`-alone custom-to-native locomotion recovery request; custom
software must not intercept or redefine the native damping chord.

While the connected B2 was stably standing under native control, the pinned
official `MotionSwitcherClient.CheckMode` returned `form=0, name=ai`; the
official B2 example maps that to `ai_sport`. Recovery must not assume `normal`:
the reviewed adapter must preserve the approved native target and confirm it
again with `CheckMode` after handover.

## 2026-08-11 read-only commissioning recheck

With the robot stably standing in native `form=0, name=ai`, a 10-second state
gate received `5028` valid samples at approximately `502..504 Hz`, with zero
CRC errors and zero invalid samples. A second 12-second run received `6001`
valid samples, again with zero CRC errors and zero invalid samples.

The simultaneous learned-hold dry-run consumed `501` mirrored real-state
samples. Maximum ONNX inference time was `1.839 ms`, maximum absolute actor
output was `1.658`, minimum candidate-target margin to the model joint ranges
was `0.655 rad`, and maximum measured-to-candidate target difference remained
`0.387 rad`. This passes state transport and inference validity only. The
remaining posture discontinuity continues to block abrupt motor handover.

The following `0.25 m/s` forward-command dry-run also consumed `501` real-state
samples. Maximum inference time was `1.425 ms`, maximum absolute actor output
was `1.625`, minimum model-range margin was `0.664 rad`, and maximum
measured-to-candidate target difference was `0.378 rad`. The forward command
produced a materially different finite action from learned hold, confirming the
command reaches the exact policy input. It remains a read-only inference pass,
not permission for abrupt motor handover.

## One-command read-only acceptance

The complete non-actuating gate is available as:

```bash
scripts/run_hardware_readonly_acceptance.sh enp8s0 \
  '/absolute/path/to/b2_policy_deployment_handoff'
```

It checks native `CheckMode`, a three-second state/CRC gate, a ten-second
learned-hold shadow, and a ten-second `0.25 m/s` forward shadow. The script and
both child processes contain no `LowCmd` publisher.

The 2026-08-11 acceptance run passed in native `form=0, name=ai`. The hold and
forward state gates each received `6000` valid samples with zero CRC and invalid
samples; each policy shadow consumed `501` samples. Hold measured `1.442 ms`
maximum inference time, `0.417 rad` maximum state-to-candidate gap, and
`0.603 rad` minimum model-limit margin. Forward measured `1.397 ms`,
`0.396 rad`, and `0.624 rad` respectively.

These results validate the read-only state and inference path. They also confirm
that direct target activation remains blocked: the hardware-owner-approved
gains, slew, timeouts, physical fallback, and native/custom handover are still
absent. The zero-motion profile in `config/b2-reference-profile.json` therefore
keeps activation disabled and all motion rates at zero.
