# Unitree B2 Control Stack Delivery Roadmap

The approved specification is delivered as five sequential, independently testable implementation plans.

1. **Offline policy foundation** — reproducible Python package, bundle integrity verification, exact 45-to-12 policy contract, ONNX golden inference, and DDS-free policy core.
2. **Contracts, recorder, and visualizer** — versioned Protobuf messages, Parquet/JSONL sessions, FastAPI/WebSocket service, TypeScript live dashboard, and sim/real replay comparison.
3. **C++ gateway and simulator backend** — cross-language IPC, backend abstraction, supervisor protocol, SDK-in-MuJoCo adapter, timing tests, and fault injection.
4. **Hardware read-only commissioning** — pinned Unitree SDK state subscription, firmware inventory, joint/IMU/remote mapping tools, original-policy baseline capture, and read-only reports.
5. **Hardware control API and handoff** — hardware-owned plugin ABI, approval-manifest enforcement, conformance harness, commissioning runbooks, and evidence packaging. The actual LowCmd publisher, CRC, motor enable, native/custom handover, emergency stop, and controlled fallback remain human-authored and independently reviewed.

Each plan begins only after the prior plan's full test suite and review pass. Plans 1–4 produce runnable software without motor publication. Plan 5 produces the audited boundary through which the hardware owner's implementation can make the complete stack eligible for supported real-robot testing.
