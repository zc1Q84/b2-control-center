# Offline Policy Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a reproducible, DDS-free Python package that verifies the handed-off B2 bundle and executes the exact 45-input to 12-output policy contract offline.

**Architecture:** A small `src`-layout Python package separates bundle integrity, policy math, ONNX inference, and the stateful 50 Hz core. The package accepts an explicit bundle directory and never publishes robot commands. Unit tests cover policy math and validation; an integration command verifies the real ONNX artifact and canonical inference.

**Tech Stack:** Python 3.12, NumPy, ONNX Runtime CPU, pytest, setuptools, pip-tools

---

## Scope and file map

This plan creates only the offline foundation:

```text
.gitignore                                      local build/runtime exclusions
pyproject.toml                                  package metadata and dependencies
requirements/dev.in                            direct development dependencies
requirements/dev.txt                           hash-locked generated environment
src/b2_control/__init__.py                      package version
src/b2_control/bundle.py                        manifest and SHA-256 verification
src/b2_control/policy_math.py                   exact observation/command/action math
src/b2_control/onnx_policy.py                   validated ONNX Runtime wrapper
src/b2_control/core.py                          stateful 50 Hz policy boundary
src/b2_control/cli_verify.py                    full bundle and golden-inference CLI
tests/test_package.py                           package smoke test
tests/test_bundle.py                            bundle integrity tests
tests/test_policy_math.py                       exact tensor contract tests
tests/test_onnx_policy.py                       ONNX wrapper validation tests
tests/test_core.py                              state/reset behavior tests
tests/test_cli_verify.py                        CLI behavior tests
docs/offline-policy.md                          operator instructions
```

Protobuf, C++, web UI, recording, MuJoCo, and Unitree SDK integration belong to later roadmap plans.

### Task 1: Bootstrap the Python package

**Files:**
- Create: `.gitignore`
- Create: `pyproject.toml`
- Create: `requirements/dev.in`
- Create: `src/b2_control/__init__.py`
- Create: `tests/test_package.py`

- [ ] **Step 1: Write the failing package smoke test**

```python
# tests/test_package.py
from b2_control import __version__


def test_package_version() -> None:
    assert __version__ == "0.1.0"
```

- [ ] **Step 2: Create a temporary test environment and verify the test fails**

Run:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install pytest==8.4.1
.venv/bin/python -m pytest tests/test_package.py -v
```

Expected: collection fails with `ModuleNotFoundError: No module named 'b2_control'`.

- [ ] **Step 3: Add package metadata and the minimal package**

```toml
# pyproject.toml
[build-system]
requires = ["setuptools>=75", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "b2-control-stack"
version = "0.1.0"
description = "Offline-first control development stack for a bare Unitree B2"
requires-python = ">=3.12,<3.13"
dependencies = [
  "numpy>=1.26,<3",
  "onnxruntime>=1.17,<2",
]

[project.optional-dependencies]
dev = [
  "pip-tools==7.5.0",
  "pytest==8.4.1",
  "pytest-cov==6.2.1",
]

[project.scripts]
b2-verify-bundle = "b2_control.cli_verify:main"

[tool.setuptools]
package-dir = {"" = "src"}

[tool.setuptools.packages.find]
where = ["src"]

[tool.pytest.ini_options]
addopts = "-ra --strict-markers"
testpaths = ["tests"]
markers = [
  "integration: requires the real policy bundle",
]
```

```text
# requirements/dev.in
numpy>=1.26,<3
onnxruntime>=1.17,<2
pip==25.2
pip-tools==7.5.0
pytest==8.4.1
pytest-cov==6.2.1
```

```python
# src/b2_control/__init__.py
"""Offline-first Unitree B2 control development stack."""

__version__ = "0.1.0"
```

```gitignore
# .gitignore
.venv/
__pycache__/
*.py[cod]
.pytest_cache/
.coverage
htmlcov/
build/
dist/
*.egg-info/
var/
.superpowers/
```

- [ ] **Step 4: Install the package, lock dependencies, and verify the test passes**

Run:

```bash
.venv/bin/python -m pip install -e '.[dev]'
.venv/bin/pip-compile --generate-hashes --allow-unsafe --output-file requirements/dev.txt requirements/dev.in
.venv/bin/python -m pytest tests/test_package.py -v
```

Expected: `1 passed`; `requirements/dev.txt` is generated with hashes.

- [ ] **Step 5: Commit the bootstrap**

```bash
git add .gitignore pyproject.toml requirements src tests/test_package.py
git commit -m "build: bootstrap offline B2 policy package"
```

### Task 2: Verify bundle manifests and artifacts

**Files:**
- Create: `src/b2_control/bundle.py`
- Create: `tests/test_bundle.py`

- [ ] **Step 1: Write bundle verification tests**

```python
# tests/test_bundle.py
import hashlib
import json
from pathlib import Path

import pytest

import b2_control.bundle as bundle_module
from b2_control.bundle import BundleError, open_verified_bundle


def _write_bundle(root: Path, payload: bytes = b"policy") -> Path:
    model = root / "models" / "policy.onnx"
    model.parent.mkdir(parents=True)
    model.write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    manifest = {
        "recommended_runtime_artifact": "models/policy.onnx",
        "policy_contract": {
            "actor_input_dim": 45,
            "actor_output_dim": 12,
            "input_dtype": "float32",
            "output_dtype": "float32",
            "policy_rate_hz": 50,
        },
        "artifacts": [
            {"path": "models/policy.onnx", "sha256": digest, "role": "actor"}
        ],
    }
    (root / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return model


def test_open_verified_bundle_accepts_matching_hash(tmp_path: Path) -> None:
    model = _write_bundle(tmp_path)
    bundle = open_verified_bundle(tmp_path)
    assert bundle.policy_path == model.resolve()
    assert bundle.policy_rate_hz == 50


def test_open_verified_bundle_rejects_hash_mismatch(tmp_path: Path) -> None:
    model = _write_bundle(tmp_path)
    model.write_bytes(b"changed")
    with pytest.raises(BundleError, match="SHA-256 mismatch"):
        open_verified_bundle(tmp_path)


def test_open_verified_bundle_rejects_wrong_contract(tmp_path: Path) -> None:
    _write_bundle(tmp_path)
    manifest_path = tmp_path / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["policy_contract"]["actor_input_dim"] = 48
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(BundleError, match="45 -> 12"):
        open_verified_bundle(tmp_path)


def test_open_verified_bundle_rejects_non_object_contract(tmp_path: Path) -> None:
    _write_bundle(tmp_path)
    manifest_path = tmp_path / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["policy_contract"] = None
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(BundleError, match="policy_contract must be an object"):
        open_verified_bundle(tmp_path)


def test_open_verified_bundle_rejects_non_object_artifact(tmp_path: Path) -> None:
    _write_bundle(tmp_path)
    manifest_path = tmp_path / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["artifacts"] = [None]
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(BundleError, match="Artifact entries must be objects"):
        open_verified_bundle(tmp_path)


def test_open_verified_bundle_rejects_unverified_recommended_policy(
    tmp_path: Path,
) -> None:
    _write_bundle(tmp_path)
    unverified = tmp_path / "models" / "unverified.onnx"
    unverified.write_bytes(b"unverified")
    manifest_path = tmp_path / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["recommended_runtime_artifact"] = "models/unverified.onnx"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(
        BundleError, match="recommended runtime artifact is not a verified artifact"
    ):
        open_verified_bundle(tmp_path)


def test_open_verified_bundle_rejects_parent_artifact_escape(tmp_path: Path) -> None:
    root = tmp_path / "bundle"
    _write_bundle(root)
    outside = tmp_path / "outside.onnx"
    outside.write_bytes(b"outside")
    manifest_path = root / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["artifacts"] = [
        {
            "path": "../outside.onnx",
            "sha256": hashlib.sha256(b"outside").hexdigest(),
        }
    ]
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(BundleError, match="Artifact escapes bundle root"):
        open_verified_bundle(root)


def test_open_verified_bundle_rejects_artifact_symlink_escape(
    tmp_path: Path,
) -> None:
    root = tmp_path / "bundle"
    _write_bundle(root)
    outside = tmp_path / "outside.onnx"
    outside.write_bytes(b"outside")
    link = root / "models" / "external.onnx"
    link.symlink_to(outside)
    manifest_path = root / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["artifacts"].append(
        {
            "path": "models/external.onnx",
            "sha256": hashlib.sha256(b"outside").hexdigest(),
        }
    )
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(BundleError, match="Artifact escapes bundle root"):
        open_verified_bundle(root)


def test_open_verified_bundle_rejects_recommended_symlink_escape(
    tmp_path: Path,
) -> None:
    root = tmp_path / "bundle"
    _write_bundle(root)
    outside = tmp_path / "outside.onnx"
    outside.write_bytes(b"outside")
    link = root / "models" / "external.onnx"
    link.symlink_to(outside)
    manifest_path = root / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["recommended_runtime_artifact"] = "models/external.onnx"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(
        BundleError, match="Recommended runtime artifact escapes bundle root"
    ):
        open_verified_bundle(root)


def test_open_verified_bundle_rejects_manifest_symlink_escape(tmp_path: Path) -> None:
    root = tmp_path / "bundle"
    _write_bundle(root)
    manifest_path = root / "manifest.json"
    external_manifest = tmp_path / "external.json"
    external_manifest.write_bytes(manifest_path.read_bytes())
    manifest_path.unlink()
    manifest_path.symlink_to(external_manifest)
    with pytest.raises(BundleError, match="Manifest escapes bundle root"):
        open_verified_bundle(root)


def test_open_verified_bundle_accepts_internal_manifest_symlink(
    tmp_path: Path,
) -> None:
    model = _write_bundle(tmp_path)
    manifest_path = tmp_path / "manifest.json"
    internal_manifest = tmp_path / "metadata" / "manifest.json"
    internal_manifest.parent.mkdir()
    manifest_path.replace(internal_manifest)
    manifest_path.symlink_to(Path("metadata") / "manifest.json")
    bundle = open_verified_bundle(tmp_path)
    assert bundle.policy_path == model.resolve()


def test_open_verified_bundle_rejects_invalid_manifest_utf8(tmp_path: Path) -> None:
    (tmp_path / "manifest.json").write_bytes(b"\xff")
    with pytest.raises(BundleError, match="Cannot read bundle manifest"):
        open_verified_bundle(tmp_path)


def test_open_verified_bundle_translates_artifact_hash_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _write_bundle(tmp_path)

    def fail_to_hash(path: Path) -> str:
        raise OSError("denied")

    monkeypatch.setattr(bundle_module, "_sha256_file", fail_to_hash)
    with pytest.raises(BundleError, match="Cannot hash artifact") as exc_info:
        open_verified_bundle(tmp_path)
    assert isinstance(exc_info.value.__cause__, OSError)
    assert str(exc_info.value.__cause__) == "denied"


def test_open_verified_bundle_translates_artifact_resolution_error(
    tmp_path: Path,
) -> None:
    _write_bundle(tmp_path)
    loop = tmp_path / "models" / "loop.onnx"
    loop.symlink_to("loop.onnx")
    manifest_path = tmp_path / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["artifacts"].append(
        {"path": "models/loop.onnx", "sha256": "0" * 64}
    )
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(BundleError, match="Cannot resolve artifact"):
        open_verified_bundle(tmp_path)


def test_open_verified_bundle_translates_malformed_artifact_path(
    tmp_path: Path,
) -> None:
    _write_bundle(tmp_path)
    manifest_path = tmp_path / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["artifacts"][0]["path"] = "models/policy.onnx\u0000suffix"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(BundleError, match="Cannot resolve artifact") as exc_info:
        open_verified_bundle(tmp_path)
    assert isinstance(exc_info.value.__cause__, ValueError)


def test_open_verified_bundle_translates_malformed_root_path() -> None:
    with pytest.raises(
        BundleError, match="Cannot resolve bundle directory"
    ) as exc_info:
        open_verified_bundle("/tmp/b2\u0000bundle")
    assert isinstance(exc_info.value.__cause__, ValueError)
```

- [ ] **Step 2: Run the tests and confirm they fail**

Run: `.venv/bin/python -m pytest tests/test_bundle.py -v`

Expected: collection fails because `b2_control.bundle` does not exist.

- [ ] **Step 3: Implement strict bundle verification**

```python
# src/b2_control/bundle.py
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any


class BundleError(RuntimeError):
    """The policy bundle is incomplete or violates the deployment contract."""


@dataclass(frozen=True)
class VerifiedBundle:
    root: Path
    manifest: dict[str, Any]
    policy_path: Path
    policy_rate_hz: int


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _resolve_bundle_child(root: Path, relative: str, label: str) -> Path:
    try:
        resolved = (root / relative).resolve()
    except (OSError, RuntimeError, ValueError) as exc:
        raise BundleError(f"Cannot resolve {label.lower()} {relative}: {exc}") from exc
    if root not in resolved.parents:
        raise BundleError(f"{label} escapes bundle root: {relative}")
    return resolved


def _load_manifest(root: Path) -> dict[str, Any]:
    manifest_path = _resolve_bundle_child(root, "manifest.json", "Manifest")
    if not manifest_path.is_file():
        raise BundleError(f"Missing bundle manifest: {manifest_path}")
    try:
        value = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise BundleError(f"Cannot read bundle manifest: {exc}") from exc
    if not isinstance(value, dict):
        raise BundleError("Bundle manifest root must be an object")
    return value


def open_verified_bundle(path: str | Path) -> VerifiedBundle:
    candidate = Path(path)
    try:
        root = candidate.expanduser().resolve()
    except (OSError, RuntimeError, ValueError) as exc:
        raise BundleError(f"Cannot resolve bundle directory {candidate}: {exc}") from exc
    if not root.is_dir():
        raise BundleError(f"Bundle directory does not exist: {root}")
    manifest = _load_manifest(root)

    contract = manifest.get("policy_contract")
    if not isinstance(contract, dict):
        raise BundleError("policy_contract must be an object")
    signature = (
        contract.get("actor_input_dim"),
        contract.get("actor_output_dim"),
        contract.get("input_dtype"),
        contract.get("output_dtype"),
    )
    if signature != (45, 12, "float32", "float32"):
        raise BundleError(f"Expected float32 45 -> 12 policy contract, got {signature}")
    if contract.get("policy_rate_hz") != 50:
        raise BundleError("Expected 50 Hz policy rate")

    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, list) or not artifacts:
        raise BundleError("Bundle manifest has no artifacts")
    verified_artifacts: set[Path] = set()
    for item in artifacts:
        if not isinstance(item, dict):
            raise BundleError("Artifact entries must be objects")
        relative = item.get("path")
        expected = item.get("sha256")
        if not isinstance(relative, str) or not isinstance(expected, str):
            raise BundleError("Artifact entries require path and sha256 strings")
        artifact = _resolve_bundle_child(root, relative, "Artifact")
        if not artifact.is_file():
            raise BundleError(f"Missing artifact: {relative}")
        try:
            actual = _sha256_file(artifact)
        except OSError as exc:
            raise BundleError(f"Cannot hash artifact {relative}: {exc}") from exc
        if actual != expected:
            raise BundleError(
                f"SHA-256 mismatch for {relative}: {actual} != {expected}"
            )
        verified_artifacts.add(artifact)

    recommended = manifest.get("recommended_runtime_artifact")
    if not isinstance(recommended, str):
        raise BundleError("Missing recommended_runtime_artifact")
    policy_path = _resolve_bundle_child(root, recommended, "Recommended runtime artifact")
    if not policy_path.is_file():
        raise BundleError(f"Invalid recommended policy path: {recommended}")
    if policy_path not in verified_artifacts:
        raise BundleError(
            f"recommended runtime artifact is not a verified artifact: {recommended}"
        )
    return VerifiedBundle(root, manifest, policy_path, 50)
```

- [ ] **Step 4: Run the bundle tests**

Run: `.venv/bin/python -m pytest tests/test_bundle.py -v`

Expected: `16 passed`.

- [ ] **Step 5: Commit bundle verification**

```bash
git add src/b2_control/bundle.py tests/test_bundle.py
git commit -m "feat: verify B2 policy bundle integrity"
```

### Task 3: Implement the exact policy math

**Files:**
- Create: `src/b2_control/policy_math.py`
- Create: `tests/test_policy_math.py`

- [ ] **Step 1: Write exact contract tests**

```python
# tests/test_policy_math.py
import numpy as np
import pytest

from b2_control.policy_math import (
    ACTION_SCALE,
    Q_DEFAULT,
    build_observation,
    heading_first_command,
    joint_targets,
)


def test_level_default_hold_observation_is_zero_except_gravity() -> None:
    observation = build_observation(
        omega_body=np.zeros(3),
        rotation_body_to_world=np.eye(3),
        command=np.zeros(3),
        q=Q_DEFAULT,
        dq=np.zeros(12),
        previous_action=np.zeros(12),
    )
    expected = np.zeros((1, 45), dtype=np.float32)
    expected[0, 3:6] = [0.0, 0.0, -1.0]
    np.testing.assert_array_equal(observation, expected)


def test_heading_command_holds_exact_zero() -> None:
    command, error, gate = heading_first_command(1.0, 0.0, 0.25, hold=True)
    np.testing.assert_array_equal(command, np.zeros(3, dtype=np.float32))
    assert error == pytest.approx(1.0)
    assert 0.0 < gate < 1.0


def test_negative_nominal_speed_is_rejected() -> None:
    with pytest.raises(ValueError, match="non-negative"):
        heading_first_command(0.0, 0.0, -0.25)


def test_joint_targets_use_exact_scale() -> None:
    action = np.ones(12)
    targets = joint_targets(action)
    assert targets.shape == (12,)
    assert targets.dtype == np.float64
    assert targets.flags.c_contiguous
    np.testing.assert_allclose(targets, Q_DEFAULT + ACTION_SCALE)
```

Also cover every validation boundary: exact read-only public constants; wrong,
non-finite, unconvertible, and overflowing vectors; rotation
shape/finiteness/orthonormality/handedness and conversion overflow; scalar shape,
finiteness, and conversion overflow; negative or float32-overflowing speed; heading
wrap (including extreme finite and antipodal headings); yaw-rate clipping; and exact
observation/command/joint-target order, scaling, dtype, shape, finite output, and
C-contiguous layout.

- [ ] **Step 2: Run the tests and confirm they fail**

Run: `.venv/bin/python -m pytest tests/test_policy_math.py -v`

Expected: collection fails because `b2_control.policy_math` does not exist.

- [ ] **Step 3: Implement the validated math boundary**

```python
# src/b2_control/policy_math.py
from __future__ import annotations

from typing import Any

import numpy as np


JOINT_NAMES = (
    "FR_hip_joint",
    "FR_thigh_joint",
    "FR_calf_joint",
    "FL_hip_joint",
    "FL_thigh_joint",
    "FL_calf_joint",
    "RR_hip_joint",
    "RR_thigh_joint",
    "RR_calf_joint",
    "RL_hip_joint",
    "RL_thigh_joint",
    "RL_calf_joint",
)
Q_DEFAULT = np.array(
    (
        -0.1,
        0.8,
        -1.5,
        0.1,
        0.8,
        -1.5,
        -0.1,
        1.0,
        -1.5,
        0.1,
        1.0,
        -1.5,
    ),
    dtype=np.float64,
)
ACTION_SCALE = np.array((0.125, 0.25, 0.25) * 4, dtype=np.float64)
Q_DEFAULT.setflags(write=False)
ACTION_SCALE.setflags(write=False)
OBSERVATION_DIM = 45
ACTION_DIM = 12


def _vector(value: Any, size: int, name: str) -> np.ndarray:
    try:
        array = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite numeric vector") from exc
    if array.shape != (size,):
        raise ValueError(f"{name} must have shape ({size},), got {array.shape}")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} contains non-finite values")
    return array


def _scalar(value: Any, name: str) -> float:
    try:
        array = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite scalar") from exc
    if array.shape != ():
        raise ValueError(f"{name} must be a scalar, got shape {array.shape}")
    scalar = float(array)
    if not np.isfinite(scalar):
        raise ValueError(f"{name} must be finite")
    return scalar


def build_observation(
    *,
    omega_body: Any,
    rotation_body_to_world: Any,
    command: Any,
    q: Any,
    dq: Any,
    previous_action: Any,
) -> np.ndarray:
    omega = _vector(omega_body, 3, "omega_body")
    cmd = _vector(command, 3, "command")
    joint_position = _vector(q, ACTION_DIM, "q")
    joint_velocity = _vector(dq, ACTION_DIM, "dq")
    last_action = _vector(previous_action, ACTION_DIM, "previous_action")

    try:
        rotation = np.asarray(rotation_body_to_world, dtype=np.float64)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(
            "rotation_body_to_world must be a finite numeric matrix"
        ) from exc
    if rotation.shape != (3, 3):
        raise ValueError(
            f"rotation_body_to_world must have shape (3, 3), got {rotation.shape}"
        )
    if not np.all(np.isfinite(rotation)):
        raise ValueError("rotation_body_to_world must contain only finite values")
    if not np.allclose(
        rotation.T @ rotation,
        np.eye(3, dtype=np.float64),
        rtol=1e-5,
        atol=1e-5,
    ):
        raise ValueError("rotation_body_to_world must be orthonormal")
    if not np.isclose(np.linalg.det(rotation), 1.0, rtol=1e-5, atol=1e-5):
        raise ValueError("rotation_body_to_world must have determinant +1")

    projected_gravity = rotation.T @ np.array((0.0, 0.0, -1.0))
    raw_observation = np.concatenate(
        (
            0.25 * omega,
            projected_gravity,
            cmd,
            joint_position - Q_DEFAULT,
            0.05 * joint_velocity,
            last_action,
        )
    )
    with np.errstate(over="ignore", invalid="ignore"):
        observation = raw_observation.astype(np.float32, copy=False)
    if not np.all(np.isfinite(observation)):
        raise ValueError("observation cannot be represented as finite float32")
    return np.ascontiguousarray(observation.reshape(1, OBSERVATION_DIM))


def heading_first_command(
    target_heading: float,
    current_heading: float,
    nominal_speed: float,
    *,
    hold: bool = False,
) -> tuple[np.ndarray, float, float]:
    target = _scalar(target_heading, "target_heading")
    current = _scalar(current_heading, "current_heading")
    speed = _scalar(nominal_speed, "nominal_speed")
    if speed < 0.0:
        raise ValueError("nominal_speed must be non-negative")

    full_turn = 2.0 * np.pi
    reduced_delta = target % full_turn - current % full_turn
    error = float((reduced_delta + np.pi) % full_turn - np.pi)
    gate = float(np.exp(-((error / 0.55) ** 2)))
    if hold:
        command = np.zeros(3, dtype=np.float32)
    else:
        with np.errstate(over="ignore", invalid="ignore"):
            command = np.array(
                (speed * gate, 0.0, np.clip(error, -1.0, 1.0)),
                dtype=np.float32,
            )
        if not np.all(np.isfinite(command)):
            raise ValueError("command cannot be represented as finite float32")
    return command, error, gate


def joint_targets(action: Any) -> np.ndarray:
    return Q_DEFAULT + ACTION_SCALE * _vector(action, ACTION_DIM, "action")
```

- [ ] **Step 4: Run policy math tests**

Run: `.venv/bin/python -m pytest tests/test_policy_math.py -v`

Expected: `41 passed`.

- [ ] **Step 5: Commit policy math**

```bash
git add src/b2_control/policy_math.py tests/test_policy_math.py
git commit -m "feat: implement exact B2 policy math"
```

### Task 4: Add the validated ONNX wrapper

**Files:**
- Create: `src/b2_control/onnx_policy.py`
- Create: `tests/test_onnx_policy.py`

- [ ] **Step 1: Write tensor-contract tests**

```python
# tests/test_onnx_policy.py
import pytest

from b2_control.onnx_policy import validate_tensor_contract


def test_accepts_static_actor_contract() -> None:
    validate_tensor_contract("input", [1, 45], "tensor(float)", 45)
    validate_tensor_contract("output", [1, 12], "tensor(float)", 12)


@pytest.mark.parametrize(
    ("shape", "tensor_type", "message"),
    [
        ([1, 44], "tensor(float)", "feature dimension"),
        ([1, 45], "tensor(double)", "float32"),
        ([45], "tensor(float)", "rank 2"),
    ],
)
def test_rejects_invalid_contract(shape, tensor_type, message) -> None:
    with pytest.raises(ValueError, match=message):
        validate_tensor_contract("input", shape, tensor_type, 45)
```

Also cover dynamic and invalid batch dimensions, malformed shapes, missing model
files, exact input/output count and metadata, CPU provider selection, contiguous
float32 feeds, vector reshaping, malformed/non-finite/overflowing inputs and
outputs, and exact returned action dtype, shape, and layout.

- [ ] **Step 2: Run the tests and confirm they fail**

Run: `.venv/bin/python -m pytest tests/test_onnx_policy.py -v`

Expected: collection fails because `b2_control.onnx_policy` does not exist.

- [ ] **Step 3: Implement the ONNX wrapper**

```python
# src/b2_control/onnx_policy.py
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from .policy_math import ACTION_DIM, OBSERVATION_DIM


def validate_tensor_contract(
    label: str,
    shape: Any,
    tensor_type: str,
    feature_dim: int,
) -> None:
    if tensor_type != "tensor(float)":
        raise ValueError(f"Policy {label} must use float32, got {tensor_type!r}")
    try:
        rank = len(shape)
    except TypeError as exc:
        raise ValueError(f"Policy {label} must be rank 2, got {shape!r}") from exc
    if rank != 2:
        raise ValueError(f"Policy {label} must be rank 2, got {shape}")
    batch_dim, actual_feature_dim = shape
    if batch_dim != 1 and batch_dim is not None and not isinstance(batch_dim, str):
        raise ValueError(
            f"Policy {label} batch dimension must accept one sample, got {batch_dim!r}"
        )
    if actual_feature_dim != feature_dim:
        raise ValueError(
            f"Policy {label} feature dimension must be {feature_dim}, got {shape}"
        )


class OnnxPolicy:
    def __init__(self, path: str | Path):
        candidate = Path(path)
        try:
            self.path = candidate.expanduser().resolve()
        except (OSError, RuntimeError, ValueError) as exc:
            raise ValueError(f"Cannot resolve ONNX policy path {candidate!s}") from exc
        if not self.path.is_file():
            raise FileNotFoundError(self.path)

        import onnxruntime as ort

        self._session = ort.InferenceSession(
            str(self.path), providers=["CPUExecutionProvider"]
        )
        inputs = self._session.get_inputs()
        outputs = self._session.get_outputs()
        if len(inputs) != 1 or len(outputs) != 1:
            raise ValueError("Actor must have exactly one input and one output")
        self._input = inputs[0]
        self._output = outputs[0]
        validate_tensor_contract(
            "input", self._input.shape, self._input.type, OBSERVATION_DIM
        )
        validate_tensor_contract(
            "output", self._output.shape, self._output.type, ACTION_DIM
        )
        self.input_name = self._input.name
        self.output_name = self._output.name

    def infer(self, observation: Any) -> np.ndarray:
        try:
            with np.errstate(over="ignore", invalid="ignore"):
                obs = np.asarray(observation, dtype=np.float32)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("observation must be convertible to float32") from exc
        if obs.shape == (OBSERVATION_DIM,):
            obs = obs.reshape(1, OBSERVATION_DIM)
        if obs.shape != (1, OBSERVATION_DIM):
            raise ValueError("observation must have shape (1, 45)")
        if not np.all(np.isfinite(obs)):
            raise ValueError(
                "observation must be representable as finite float32"
            )
        feed = np.ascontiguousarray(obs)

        result = self._session.run(
            [self.output_name], {self.input_name: feed}
        )
        if not isinstance(result, (list, tuple)) or len(result) != 1:
            raise RuntimeError("Policy output must contain exactly one tensor")
        try:
            with np.errstate(over="ignore", invalid="ignore"):
                action = np.asarray(result[0], dtype=np.float32)
        except (TypeError, ValueError, OverflowError) as exc:
            raise RuntimeError("Policy output is not convertible to float32") from exc
        if action.shape != (1, ACTION_DIM):
            raise RuntimeError("Policy output must have shape (1, 12)")
        if not np.all(np.isfinite(action)):
            raise RuntimeError(
                "Policy output must be representable as finite float32"
            )
        return np.ascontiguousarray(action.reshape(ACTION_DIM))
```

- [ ] **Step 4: Run ONNX wrapper tests**

Run: `.venv/bin/python -m pytest tests/test_onnx_policy.py -v`

Expected: `32 passed`.

- [ ] **Step 5: Commit ONNX validation**

```bash
git add src/b2_control/onnx_policy.py tests/test_onnx_policy.py
git commit -m "feat: validate and execute ONNX actor"
```

### Task 5: Build the stateful 50 Hz policy core

**Files:**
- Create: `src/b2_control/core.py`
- Create: `tests/test_core.py`

- [ ] **Step 1: Write state/reset tests with a fake actor**

```python
# tests/test_core.py
import numpy as np

from b2_control.core import B2PolicyCore
from b2_control.policy_math import ACTION_SCALE, Q_DEFAULT


class FakePolicy:
    def __init__(self):
        self.observations = []

    def infer(self, observation):
        self.observations.append(np.asarray(observation).copy())
        return np.full(12, len(self.observations), dtype=np.float32)


def _step(core):
    return core.step(
        omega_body_rad_s=np.zeros(3),
        rotation_body_to_world=np.eye(3),
        joint_position_rad=Q_DEFAULT,
        joint_velocity_rad_s=np.zeros(12),
        target_yaw_rad=0.0,
        current_yaw_rad=0.0,
        nominal_speed_m_s=0.25,
        hold=True,
    )


def test_previous_raw_action_is_fed_back_then_reset():
    actor = FakePolicy()
    core = B2PolicyCore(actor)
    _step(core)
    _step(core)
    np.testing.assert_array_equal(actor.observations[0][0, 33:45], np.zeros(12))
    np.testing.assert_array_equal(actor.observations[1][0, 33:45], np.ones(12))
    core.reset()
    _step(core)
    np.testing.assert_array_equal(actor.observations[2][0, 33:45], np.zeros(12))


def test_hold_command_is_exact_zero():
    output = _step(B2PolicyCore(FakePolicy()))
    np.testing.assert_array_equal(output.command, np.zeros(3, dtype=np.float32))


def test_step_returns_raw_action_and_scaled_joint_targets():
    output = _step(B2PolicyCore(FakePolicy()))
    np.testing.assert_array_equal(output.raw_action, np.ones(12, dtype=np.float32))
    np.testing.assert_allclose(output.q_desired_rad, Q_DEFAULT + ACTION_SCALE)
    assert output.observation.shape == (1, 45)
    assert output.heading_error_rad == 0.0
    assert output.alignment_gate == 1.0
```

- [ ] **Step 2: Run the tests and confirm they fail**

Run: `.venv/bin/python -m pytest tests/test_core.py -v`

Expected: collection fails because `b2_control.core` does not exist.

- [ ] **Step 3: Implement the DDS-free core**

```python
# src/b2_control/core.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

import numpy as np

from .policy_math import (
    ACTION_DIM,
    build_observation,
    heading_first_command,
    joint_targets,
)


class Policy(Protocol):
    def infer(self, observation: Any) -> np.ndarray: ...


@dataclass(frozen=True)
class PolicyOutput:
    q_desired_rad: np.ndarray
    raw_action: np.ndarray
    observation: np.ndarray
    command: np.ndarray
    heading_error_rad: float
    alignment_gate: float


class B2PolicyCore:
    def __init__(self, policy: Policy):
        self.policy = policy
        self.previous_action = np.zeros(ACTION_DIM, dtype=np.float32)

    def reset(self) -> None:
        self.previous_action.fill(0.0)

    def step(
        self,
        *,
        omega_body_rad_s: Any,
        rotation_body_to_world: Any,
        joint_position_rad: Any,
        joint_velocity_rad_s: Any,
        target_yaw_rad: float,
        current_yaw_rad: float,
        nominal_speed_m_s: float,
        hold: bool,
    ) -> PolicyOutput:
        command, error, gate = heading_first_command(
            target_yaw_rad,
            current_yaw_rad,
            nominal_speed_m_s,
            hold=hold,
        )
        observation = build_observation(
            omega_body=omega_body_rad_s,
            rotation_body_to_world=rotation_body_to_world,
            command=command,
            q=joint_position_rad,
            dq=joint_velocity_rad_s,
            previous_action=self.previous_action,
        )
        action = np.asarray(self.policy.infer(observation), dtype=np.float32)
        desired = joint_targets(action)
        self.previous_action[:] = action
        return PolicyOutput(
            q_desired_rad=desired.copy(),
            raw_action=action.copy(),
            observation=observation.copy(),
            command=command.copy(),
            heading_error_rad=error,
            alignment_gate=gate,
        )
```

- [ ] **Step 4: Run core tests**

Run: `.venv/bin/python -m pytest tests/test_core.py -v`

Expected: `3 passed`.

- [ ] **Step 5: Commit the policy core**

```bash
git add src/b2_control/core.py tests/test_core.py
git commit -m "feat: add stateful offline policy core"
```

### Task 6: Add full verification CLI and golden inference

**Files:**
- Create: `src/b2_control/cli_verify.py`
- Create: `tests/test_cli_verify.py`

- [ ] **Step 1: Write a CLI unit test**

```python
# tests/test_cli_verify.py
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

import b2_control.cli_verify as cli


PINNED_HOLD_ACTION = np.array(
    (
        0.3856276273727417,
        -0.4630189836025238,
        1.292534351348877,
        -0.4785652160644531,
        -0.5396023988723755,
        1.1809988021850586,
        0.3231983184814453,
        -0.3763878345489502,
        0.8902627229690552,
        -0.055662669241428375,
        -0.16711482405662537,
        0.8141254186630249,
    ),
    dtype=np.float32,
)


class FakePolicy:
    action = PINNED_HOLD_ACTION

    def __init__(self, path: Path):
        self.path = path

    def infer(self, observation):
        expected = np.zeros((1, 45), dtype=np.float32)
        expected[0, 3:6] = (0.0, 0.0, -1.0)
        np.testing.assert_array_equal(observation, expected)
        return self.action.copy()


def _patch_bundle_and_policy(monkeypatch, tmp_path):
    bundle = SimpleNamespace(policy_path=tmp_path / "policy.onnx")
    monkeypatch.setattr(cli, "open_verified_bundle", lambda path: bundle)
    monkeypatch.setattr(cli, "OnnxPolicy", FakePolicy)


def test_verify_reports_success(monkeypatch, capsys, tmp_path):
    _patch_bundle_and_policy(monkeypatch, tmp_path)
    assert cli.main([str(tmp_path)]) == 0
    assert "Bundle verified" in capsys.readouterr().out


def test_verify_rejects_golden_mismatch(monkeypatch, tmp_path):
    _patch_bundle_and_policy(monkeypatch, tmp_path)
    monkeypatch.setattr(FakePolicy, "action", np.zeros(12, dtype=np.float32))
    with pytest.raises(AssertionError):
        cli.main([str(tmp_path)])
```

- [ ] **Step 2: Run the test and confirm it fails**

Run: `.venv/bin/python -m pytest tests/test_cli_verify.py -v`

Expected: collection fails because `b2_control.cli_verify` does not exist.

- [ ] **Step 3: Implement the canonical verifier**

```python
# src/b2_control/cli_verify.py
from __future__ import annotations

import argparse
from collections.abc import Sequence

import numpy as np

from .bundle import open_verified_bundle
from .onnx_policy import OnnxPolicy
from .policy_math import Q_DEFAULT, build_observation


EXPECTED_HOLD_ACTION = np.array(
    (
        0.3856276273727417,
        -0.4630189836025238,
        1.292534351348877,
        -0.4785652160644531,
        -0.5396023988723755,
        1.1809988021850586,
        0.3231983184814453,
        -0.3763878345489502,
        0.8902627229690552,
        -0.055662669241428375,
        -0.16711482405662537,
        0.8141254186630249,
    ),
    dtype=np.float32,
)
EXPECTED_HOLD_ACTION.setflags(write=False)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Verify a B2 policy handoff bundle"
    )
    parser.add_argument("bundle", help="Path to the extracted deployment bundle")
    args = parser.parse_args(argv)

    bundle = open_verified_bundle(args.bundle)
    observation = build_observation(
        omega_body=np.zeros(3),
        rotation_body_to_world=np.eye(3),
        command=np.zeros(3),
        q=Q_DEFAULT,
        dq=np.zeros(12),
        previous_action=np.zeros(12),
    )
    action = OnnxPolicy(bundle.policy_path).infer(observation)
    np.testing.assert_allclose(
        action,
        EXPECTED_HOLD_ACTION,
        rtol=1e-5,
        atol=1e-6,
    )
    print(
        "Bundle verified: hashes, float32 45 -> 12 contract, "
        "and golden inference match."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

- [ ] **Step 4: Run the CLI unit test**

Run: `.venv/bin/python -m pytest tests/test_cli_verify.py -v`

Expected: `2 passed`.

- [ ] **Step 5: Run the verifier against the real handoff bundle**

Run:

```bash
.venv/bin/b2-verify-bundle '/home/zhangchi/文档/xwechat_files/wxid_zyi9sp7uwkvz22_2442/msg/file/2026-08/b2_policy_deployment_handoff(1)/b2_policy_deployment_handoff'
```

Expected:

```text
Bundle verified: hashes, float32 45 -> 12 contract, and golden inference match.
```

- [ ] **Step 6: Commit the verifier**

```bash
git add src/b2_control/cli_verify.py tests/test_cli_verify.py
git commit -m "feat: add canonical B2 bundle verifier"
```

### Task 7: Document and verify the offline foundation

**Files:**
- Create: `docs/offline-policy.md`
- Modify: `requirements/dev.txt`

- [ ] **Step 1: Write the operator guide**

```markdown
# Offline policy verification

This stage performs no DDS communication and cannot publish a robot command.

## Create the environment

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements/dev.txt
.venv/bin/python -m pip install --no-deps -e .
```

## Verify the handoff

```bash
.venv/bin/b2-verify-bundle /absolute/path/to/b2_policy_deployment_handoff
```

Success requires matching SHA-256 hashes, a float32 `45 -> 12` ONNX contract,
and the canonical hold inference. A failure blocks every later commissioning stage.

## Run tests

```bash
.venv/bin/python -m pytest -v
```
```

- [ ] **Step 2: Run the complete test suite with coverage**

Run:

```bash
.venv/bin/python -m pytest --cov=b2_control --cov-report=term-missing -v
```

Expected: all tests pass and no source module is unimported.

- [ ] **Step 3: Rebuild and validate the dependency lock**

Run:

```bash
.venv/bin/pip-compile --generate-hashes --allow-unsafe --output-file requirements/dev.txt requirements/dev.in
.venv/bin/python -m pip install --dry-run --require-hashes -r requirements/dev.txt
```

Expected: dependency resolution succeeds and the dry run reports no hash errors.

- [ ] **Step 4: Verify the working tree contains only intended files**

Run: `git status --short`

Expected: only `docs/offline-policy.md` and a regenerated `requirements/dev.txt` are listed.

- [ ] **Step 5: Commit documentation and lock verification**

```bash
git add docs/offline-policy.md requirements/dev.txt
git commit -m "docs: add offline policy verification guide"
```

- [ ] **Step 6: Record final evidence**

Run:

```bash
git log --oneline --decorate -8
.venv/bin/python -m pytest -q
.venv/bin/b2-verify-bundle '/home/zhangchi/文档/xwechat_files/wxid_zyi9sp7uwkvz22_2442/msg/file/2026-08/b2_policy_deployment_handoff(1)/b2_policy_deployment_handoff'
```

Expected: the task commits are present, the test suite passes, and the real bundle verifier prints its success line.
