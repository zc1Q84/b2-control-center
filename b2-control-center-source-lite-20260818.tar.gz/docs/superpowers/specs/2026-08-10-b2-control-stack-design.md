# Unitree B2 Control Stack Design

Status: approved in interactive design review on 2026-08-10

## 1. Objective

Build a reproducible control-development stack for a bare Unitree B2 with 12 leg joints. The stack runs on an external Ubuntu computer connected to the robot over wired Ethernet. It must support deterministic policy inference, offline replay, live diagnostics, SDK-in-MuJoCo testing, read-only hardware validation, and a gated path to supported real-robot testing.

The final system is considered real-robot-test ready only after the hardware-owned command and mode-handover plugin has been implemented, reviewed, and approved by the robot owner or designated hardware engineer. AI-authored code must not implement or modify the robot's native button mapping, emergency stop, damping behavior, CRC command publisher, motor-enable sequence, or native/custom motion-service handover.

## 2. Fixed decisions

- Host: Ubuntu 24.04 LTS, x86_64, external control computer.
- Robot: bare Unitree B2, 12 leg joints, no Piper arm and no B2-W modifications.
- Architecture: Python policy/diagnostics process plus C++ SDK gateway process.
- User interface: local web visualizer with live telemetry and replay.
- Operator input: read-only ingestion of the original Unitree B2 remote.
- Model: the handed-off `model_19998` ONNX actor.
- Moving command support: forward speed from 0.25 to 1.0 m/s, with initial real test at 0.25 m/s; zero-command hold is supported.
- Reverse command, stairs, unsupported terrain, and unsupported robot configurations remain disabled for the first commissioning release.
- Dependency revisions are pinned. Branch heads such as `main` or `latest` are not deployment inputs.

## 3. Safety and ownership boundary

The project implements the model boundary, diagnostics, recorder, visualizer, simulator backend, hardware read-only backend, supervisor protocol, test orchestration, and a typed interface for a hardware control plugin.

The following implementation remains exclusively hardware-owned:

- native motion-service release and reacquisition;
- low-level command message construction and CRC;
- firmware-specific motor mode and enable/disable sequence;
- approved gains, joint limits, target slew/rate limits, torque/current constraints, temperature/fault thresholds, and controlled fallback;
- physical emergency-stop and damping behavior;
- native remote button behavior.

The visualizer and policy service cannot publish motor commands. The C++ gateway cannot enter hardware-control mode unless an approved hardware plugin and matching approval manifest are present. Missing, incomplete, mismatched, or expired approval data leaves the program in read-only mode.

## 4. Architecture

### 4.1 Operator and diagnostics layer

The original Unitree remote is consumed read-only. Raw axes and button transitions are recorded before mapping. The web visualizer displays health, telemetry, state-machine state, observations, actions, targets, limits, and warnings. The web UI may issue commands to simulator sessions. In hardware sessions it is read-only by default and cannot independently enable control.

### 4.2 Python policy service

The Python service runs the actor at 50 Hz and reuses the handed-off policy contract rather than reimplementing it from memory. Each tick:

1. receives a timestamped `RobotState` snapshot;
2. validates shape, finiteness, frame metadata, sequence, and freshness;
3. maps an approved operator intent to `[forward_velocity, 0, yaw_rate]`;
4. constructs the exact 45-dimensional observation;
5. runs the ONNX actor;
6. validates the 12-dimensional raw action;
7. computes the unclipped learned joint targets;
8. emits a timestamped `PolicyResult` and complete diagnostic record.

The service resets previous-action state on activation and reset. It never injects training noise and never treats learned hold as an emergency fallback.

### 4.3 C++ gateway

The gateway owns the local IPC server, atomic robot-state snapshots, backend selection, mode/supervisor interface, and high-rate timing boundary. Exactly one backend may be active.

Included backends are:

- simulator backend: full implementation against the supported SDK-in-MuJoCo bridge;
- hardware read-only backend: subscribes to robot state and exposes firmware, joint, IMU, battery, temperature, and fault diagnostics without publishing commands;
- hardware control API: interface and conformance tests only. The robot owner supplies the implementation.

### 4.4 Local IPC

Python and C++ communicate over local Unix `SOCK_SEQPACKET` sockets using versioned Protobuf messages. Messages contain schema version, session ID, monotonic timestamp, sequence number, source state sequence, and health information. Both ends use bounded queues and non-blocking or deadline-bounded operations. A disconnect or incompatible schema is visible and fail-closed.

## 5. Runtime state machine

### 5.1 Commissioning gates

The commissioning sequence is strictly ordered:

1. `S0_OFFLINE`: bundle verification, golden inference, unit tests, and log replay.
2. `S1_HARDWARE_READONLY`: firmware capture and read-only joint/IMU/remote mapping.
3. `S2_SIM_VALIDATED`: the exact gateway and policy processes pass SDK-in-MuJoCo and fault-injection tests.
4. `S3_SUPPORTED_ZERO_COMMAND`: a physically supported robot begins at zero command after human approval and verified native recovery.
5. `S4_FLAT_SHORT_TRIAL`: a short, supported flat-ground trial at 0.25 m/s with complete logging.

No software option skips a gate. Evidence from each gate is stored in the session manifest.

### 5.2 Operating modes

- `NATIVE_ACTIVE`: native Unitree locomotion owns control.
- `CUSTOM_ARMED`: the custom policy runs and records data but does not own motor publication.
- `CUSTOM_ACTIVE`: the reviewed hardware plugin owns publication while all heartbeats and gates remain healthy.
- `HANDOVER_PENDING`: custom targets are no longer accepted while the hardware plugin performs the reviewed recovery procedure.
- `FAULT_LATCHED`: a serious failure has occurred; automatic re-enable is prohibited.

The B button is observed as a high-level `RECOVERY_REQUEST` while custom control is active. It does not directly send a damping or motor command. The hardware plugin must stop custom publication, perform the reviewed vendor-supported handover, confirm native locomotion availability, and only then report `NATIVE_ACTIVE`. Handover failure invokes the hardware-owned controlled fallback. Physical emergency stop remains independent and higher priority.

## 6. Project modules

```text
b2_control_stack/
  contracts/                  versioned Protobuf schemas
  policy_service/             Python observation, command and ONNX service
  gateway_cpp/                C++ IPC, state snapshots and backend interface
  backends/simulator/         SDK-in-MuJoCo backend
  backends/hardware_readonly/ hardware LowState diagnostics
  backends/hardware_control_api/ reviewed plugin ABI and conformance tests
  visualizer/                 FastAPI/WebSocket backend and TypeScript web UI
  recorder/                   Parquet telemetry and JSONL event recorder
  configs/                    model, network, simulation and approved profiles
  tests/                      unit, contract, replay, integration and fault tests
  tools/                      dependency bootstrap and report generation
  docs/                       setup, operation, review and commissioning guides
```

Each module has a public interface, its own tests, and no dependency on another module's internals.

## 7. Data contracts

### 7.1 `RobotState`

Contains session/sequence/timing fields, 12 joint positions, 12 joint velocities, body angular velocity, body-to-world rotation, yaw, state age, motor temperatures, fault fields, and available battery/system state. Frame and unit metadata are explicit. Invalid rotation matrices, non-finite values, wrong vector sizes, and stale or out-of-order states are rejected.

### 7.2 `OperatorIntent`

Contains source, timing, dead-man status, hold status, latched target yaw, nominal forward speed, and a mode request. The mapper records raw remote input and SI-unit output. A displayed 0.25 m/s must appear as 0.25 in observation slice `6:9`, subject only to the documented heading alignment gate.

### 7.3 `PolicyResult`

Contains source state sequence, inference timing, command `[3]`, observation `[45]`, raw actor action `[12]`, learned desired joint position `[12]`, validation status, and reason codes. It contains candidate targets, not hardware authorization.

### 7.4 `SupervisorEvent`

Contains state-machine transition, gate stage, watchdog flags, heartbeat ages, rejection/cropping counters, operator acknowledgement, backend status, and a stable reason code.

### 7.5 End-to-end correlation

One session ID and monotonic timeline correlate raw remote input, SI command, observation, actor output, candidate target, hardware-plugin audit record, and robot feedback. Simulator and hardware sessions can be aligned by command and state sequence for per-joint comparison.

## 8. Recorder and visualizer

Numerical time-series data is written to Parquet. State transitions, warnings, acknowledgements, version metadata, and failures are written as JSON Lines. Each session has a manifest containing hashes of the model, configs, schemas, binaries, dependency commits, and hardware approval profile.

The live visualizer provides:

- connection, firmware, backend, gate, mode, heartbeat, and alarm summary;
- 12-joint position, velocity, actor action, candidate target, and approved-target audit plots;
- observation slices, projected gravity, command mapping, and previous action;
- latency, dropped/late frame, queue, clipping, and watchdog charts;
- raw remote input beside mapped SI commands;
- read-only hardware diagnostics.

The replay view selects simulator and hardware sessions, aligns them, overlays each joint and actor channel, calculates errors and latency differences, and exports a diagnostic report. It never republishes recorded targets to hardware.

## 9. Error handling

The system fails closed. Configuration errors, hash/version mismatch, stale or invalid state, non-finite values, model errors, IPC failure, unavailable backend, or absent hardware approval prevent entry to `CUSTOM_ACTIVE`.

Serious failures latch. A restored network or restarted process does not automatically re-enable custom control. Re-entry requires explicit operator acknowledgement and a fresh gate evaluation.

Stale policy targets are not reused indefinitely. Exact heartbeat thresholds and physical limits come only from the approved hardware profile. The program does not provide permissive hardware defaults. If the approved profile omits a required field, hardware-control mode is unavailable.

## 10. Approved hardware profile

The hardware profile must contain all of the following:

- joint order, sign, unit, soft/hard limit, and safety margin for all 12 joints;
- target step and rate limits;
- approved position/velocity gains;
- torque and current constraints;
- tilt, angular-rate, temperature, battery, and fault thresholds;
- state, policy, IPC, publisher, and command-heartbeat deadlines;
- controlled fallback and handover semantics;
- firmware version, SDK commits, network interface, topic/message/CRC version;
- reviewer identity, review timestamp, profile hash, and plugin binary hash.

The gateway compares the profile and plugin hashes to the approval manifest before arming. A mismatch forces read-only operation.

## 11. Test strategy

### 11.1 Unit tests

Cover the exact 45-dimensional observation, rotation validation, gravity projection, command gate, previous-action reset/update, 12-joint order, learned action transform, remote scaling, sequence/timestamp logic, reason codes, and recorder schema.

### 11.2 Cross-language contract tests

Python and C++ consume the same golden Protobuf vectors. Tests cover schema versions, shapes, NaN/Inf, missing fields, incompatible messages, corrupted data, duplicates, and out-of-order messages. Bundle hashes and canonical ONNX inference are verified.

### 11.3 Offline replay

Captured LowState sessions run through the policy without publication. Repeated runs must produce identical observations and actions within specified numerical tolerances. Reports expose raw inputs, SI mapping, observations, actions, targets, timing, and rejected frames.

### 11.4 Simulator integration

The exact Python and C++ processes connect through the supported SDK-in-MuJoCo bridge. Tests cover zero hold, 0.25 m/s forward command, heading changes, mode transitions, and remote mapping. Fault injection covers stale, lost, duplicated and reordered state; policy timeout/exit; ONNX NaN or wrong shape; IPC overflow/disconnect/reconnect; invalid orientation/joint data; dead-man release; B recovery request; visualizer disconnect; and handover refusal.

Every fault must produce a deterministic transition and reason code. Silent continuation and automatic re-enable fail the test.

### 11.5 Hardware stages

1. Record an original Unitree locomotion baseline.
2. Validate all state and remote mappings without command publication.
3. Install the human-reviewed hardware plugin and matching approval manifest.
4. Verify physical stop, dead-man, B native recovery, and failure fallback under approved support.
5. Begin supported zero-command operation and smooth posture acquisition.
6. Review logs for clipping, timing, direction, and state freshness.
7. Conduct a short flat-ground 0.25 m/s trial only after the prior evidence is approved.

## 12. Definition of done

The stack is real-robot-test ready when all of the following are true:

- all unit, contract, replay, simulator and fault-injection tests pass from a clean environment;
- the policy bundle passes full hash, tensor-contract, and golden-inference verification;
- an original B2 baseline session exists;
- 12-joint, IMU, remote, command scaling, firmware, and SDK mappings pass read-only validation;
- the hardware plugin and complete hardware profile have been independently reviewed and their hashes approved;
- physical emergency stop, dead-man, native recovery, and controlled fallback have passed supported tests;
- supported zero-command operation shows no continuous clipping, stale state, timing failure, wrong direction, or anomalous target;
- the commissioning report explicitly authorizes the 0.25 m/s flat-ground trial.

The first release does not authorize custom reverse motion, stairs, unsupported terrain, unsupported payloads, or unsupported free-standing trials.

## 13. Pinned source revisions

- `unitree_sdk2_python`: `65691c8a8bc53b98d3976dba4dbf9d5d20b2e7f5`
- `unitree_sdk2`: `21d0a3b2c46ee48c8fdf2783becb6be3beb0a59b`
- `unitree_mujoco`: `ae6a8403e272733e9996ef59990880330496177f`
- deployment actor SHA-256: `688bdbc4897c6dd9cc1cce54249131a35e9206614cfad2f383d2e907978b67eb`

All dependency downloads are checksum- or commit-verified and recorded by bootstrap tooling. Upgrades require a separate review and rerun of the entire acceptance suite.
