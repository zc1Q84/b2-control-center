# B2 official MuJoCo policy loop

This path has been executed end to end with the supplied verified policy bundle.
The simulator mode uses CycloneDDS domain `1` and loopback interface `lo`.
The same policy process can also feed the separately selected hardware mode;
the C++ gateway owns all DDS and motor-command publication.

Pinned upstream sources:

- `unitree_sdk2`: `21d0a3b2c46ee48c8fdf2783becb6be3beb0a59b`
- `unitree_mujoco`: `ae6a8403e272733e9996ef59990880330496177f`
- MuJoCo: `3.3.6`

The B2 DDS actuator/sensor order reported by official MuJoCo is
`FR, FL, RR, RL`, with `hip, thigh, calf` per leg. This exactly matches the
policy manifest.

## Build

From this repository:

```bash
chmod +x scripts/*.sh
scripts/build_sim_stack.sh
```

The script builds both official Unitree MuJoCo and the policy gateway. The local
official SDK, MuJoCo, and Ubuntu dependency extracts are already in
`/home/zhangchi/.local` and `/home/zhangchi/unitree_official`; no `sudo` is
needed.

## Run

Use three terminals in this exact order.

Terminal 1:

```bash
scripts/run_b2_mujoco.sh
```

Terminal 2:

```bash
scripts/run_sim_gateway.sh
```

Terminal 3:

```bash
env PYTHONPATH=src \
  /home/zhangchi/b2_control_stack/.worktrees/offline-policy-foundation/.venv/bin/python \
  -m b2_control.cli_sim_policy \
  '/home/zhangchi/文档/xwechat_files/wxid_zyi9sp7uwkvz22_2442/msg/file/2026-08/b2_policy_deployment_handoff(1)/b2_policy_deployment_handoff' \
  --speed 0.25
```

Add `--duration 10` to produce bounded first/final 12-joint, action, target,
and inference diagnostics for sim-to-real comparison.

Expected policy output:

```text
Waiting for official B2 MuJoCo state on 127.0.0.1:15000 ...
Policy active at 50 Hz: speed=0.25 m/s, heading=... rad
```

`--speed` is restricted to the training range `0.25..1.0 m/s`. Stop the policy
with Ctrl-C first; after 100 ms without a fresh policy command the gateway
retains the last safe target in `SAFE_HOLD`. A real LowState/NaN/posture fault
still enters `SAFE_DAMPING`. Then stop the gateway and simulator.

For release-to-stop `W/S/A/D` control and stepped `Q/E` yaw input, use the
loopback browser console via `b2-policy-ui`. Full key mapping, the
`--sim-hardware-handover` parity invocation, and the hardware gateway boundary
are documented in [keyboard-teleop.md](keyboard-teleop.md).

## Boundary

The Python executable never publishes DDS or motor commands directly. Real
machine publication is only possible when the operator separately starts the
C++ gateway with its explicit `--hardware INTERFACE` acknowledgement. The
gateway remains responsible for mode switching, CRC, interpolation, watchdogs,
safe hold/damping fallback, and restoring native motion.
