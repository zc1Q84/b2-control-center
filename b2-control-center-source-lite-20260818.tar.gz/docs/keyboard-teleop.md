# B2 键盘遥控接入说明

## 已接入的内容

键盘速度状态机和非阻塞终端读取来自
`StevenLiudw/B2_sim2real` 的
`agent/document-b2-real-handoff` 分支，固定参考提交：
`2fe3e96cfdd10b6fa03402deda6927fce8d720b9`。

接入后没有替换现有控制器。键盘只产生 policy 的三维命令：

```text
[vx, vy, wz]
    ↓
45维 observation
    ↓
ONNX policy（50 Hz）
    ↓
12关节 q_target
    ↓
现有 DDS gateway（500 Hz）
    ↓
rt/lowcmd
```

因此，LowCmd 初始化、CRC、MotionSwitcher、3秒实时 policy 插值、Kp/Kd、
关节限制、通信超时和 SAFE_HOLD/SAFE_DAMPING 均继续由当前
`b2_policy_controller` 负责，键盘模块不能绕过这些保护。

## 按键

| 按键 | 作用 |
|---|---|
| `1`–`9` | 选择 W/S 的 `0.1`–`0.9 m/s` 档位；只选择速度，不触发运动 |
| `W` / `S` | 按住时以当前档位前进 / 后退，松开后 `vx=0` |
| `A` / `D` | 按住时以左移 / 右移固定速度输出 `vy`，松开后 `vy=0` |
| `Q` / `E` | 每次按下使 `wz` 增加 / 减少 `0.10 rad/s` |
| `Space` / `Z` / `R` / `X` / `Esc` | 立即清零，进入 learned hold |
| `Ctrl-C` | 退出 policy；gateway 保留最后的安全站立目标 |

仿真/真机会话在线时，主控制中心和嵌入操作台都会把键盘事件送到当前policy；在
输入框或下拉框中编辑时不会转发运动键。页面失焦或隐藏会自动发送
W/S/A/D松键，避免命令卡住。
数字键1–9动态选择W/S速度；默认档位由`--initial-linear-speed`配置，安全上限由
`--max-linear-speed`配置。A/D速度由`--max-lateral-speed`配置。Q/E每次改变
`0.10 rad/s`，并限制在
`|wz| <= 0.40 rad/s`。页面失焦或隐藏时会自动释放 W/S/A/D。

每次启动从严格的 `[0,0,0]` 开始，先运行 learned-hold warmup，再接受运动命令。

## 先在 DDS MuJoCo 使用

终端 1（自动保存录像）：

```bash
cd /home/zhangchi/b2_control_stack
B2_SIM_VIDEO=logs/videos/sim-keyboard-teleop.mp4 \
  scripts/run_b2_mujoco.sh
```

终端 2（使用与真机相同的3秒 handover）：

```bash
cd /home/zhangchi/b2_control_stack
env LD_LIBRARY_PATH=/home/zhangchi/.local/unitree-sdk2-21d0a3b/lib \
  build/gateway/b2_policy_controller --sim-hardware-handover
```

终端 3（启动浏览器操作台）：

```bash
cd /home/zhangchi/b2_control_stack
b2-policy-ui \
  '/home/zhangchi/文档/xwechat_files/wxid_zyi9sp7uwkvz22_2442/msg/file/2026-08/b2_policy_deployment_handoff(1)/b2_policy_deployment_handoff' \
  --warmup-hold-duration 3 \
  --diagnostics-csv logs/sim-keyboard-teleop-policy.csv
```

## 真机使用入口

真机网卡当前为 `enp8s0`，地址为 `192.168.123.99/24`。只有机器人恢复到
现有站姿门控认可的正常静止站姿后，才启动下面的 gateway：

```bash
cd /home/zhangchi/b2_control_stack
env LD_LIBRARY_PATH=/home/zhangchi/.local/unitree-sdk2-21d0a3b/lib \
  build/gateway/b2_policy_controller \
  --hardware enp8s0 --acknowledge-b2-low-level-control \
  --diagnostics-csv logs/hw-keyboard-controller.csv
```

另一个终端运行与仿真相同的 `b2-policy-teleop ... --interactive-keyboard`，
只把 diagnostics 路径换成 `logs/hw-keyboard-policy.csv`。程序会先保持零命令；
现场确认站立稳定后，在浏览器控制台按住 `W` 前进，松开立即回到 `vx=0`。
任何异常立即按 `Space` 或 `X` 回到 learned hold；物理急停和吊架仍是更高优先级保护。

`A/D` 横移、负 `vx` 和较大 `wz` 不能因为接口已支持就直接跳过仿真验证。

## 常驻真机控制台：原生 / 自研模式切换

现在可由同一个浏览器控制台托管 C++ gateway。控制台在原生 locomotion 下也不会
退出，因此不再需要手工开关第二个 gateway 终端：

```bash
cd /home/zhangchi/b2_control_stack
b2-policy-ui \
  '/home/zhangchi/文档/xwechat_files/wxid_zyi9sp7uwkvz22_2442/msg/file/2026-08/b2_policy_deployment_handoff(1)/b2_policy_deployment_handoff' \
  --hardware-console enp8s0 \
  --acknowledge-b2-low-level-control \
  --max-linear-speed 0.6 \
  --warmup-hold-duration 5 \
  --diagnostics-csv logs/operator-console-policy.csv
```

启动只执行 MotionSwitcher 只读检查，要求显示 `NATIVE / 原生 locomotion 已确认`；
不会自动接管或自动行走。

### “自研 locomotion”按钮

1. 浏览器弹出确认框；确认后立刻把 `[vx,vy,wz]` 清零并锁住全部运动按钮。
2. 控制台启动 `b2_policy_controller`；gateway 先接收 LowState 和零命令 ONNX
   learned-hold target，不发布 active LowCmd。
3. gateway 要求 LowState 新鲜、数据有限、站姿误差达标且关节静止；门控失败不会
   ReleaseMode。
4. 门控通过后 Release 原生 `ai`，从实测关节角到实时 learned-hold target 插值
   3 秒，保持 Kp=160、Kd=5、两级速率限制和全部既有回退。
5. 至少 5 秒 learned-hold warmup 完成且 gateway 状态为 `POLICY` 后，WASD/QE
   按钮才解锁。接管完成时速度仍是 `[0,0,0]`。

### “原生 locomotion”按钮

1. 确认后立刻清零命令并锁住运动按钮，自研 policy 继续输出零命令站立目标。
2. 必须检测到 12 关节 `max |dq| <= 0.20 rad/s` 连续 0.5 秒；不满足时只等待，
   不会强制停 gateway。
3. 静止门控通过后正常终止 gateway；gateway 先发送短时 SAFE_HOLD_EXIT，再调用
   MotionSwitcher `SelectMode("ai")`。
4. `b2_mode_probe` 必须确认 `form=0 name=ai`，控制台才显示 `NATIVE`。此时网页
   保持在线，但所有自研速度按钮禁用。

### 故障逻辑

- LowState、policy、NaN/CRC 或姿态保护异常仍由 C++ gateway fail-closed；控制台
  不会绕过 gateway 的 SAFE_HOLD / SAFE_DAMPING。
- 急停锁存时禁止控制台自动恢复 `ai`，必须先由现场人员固定机器人并单独处理。
- gateway 启动失败、站姿门控超时或 MotionSwitcher 确认失败时显示 `FAULT`，运动
  按钮保持禁用。
- 正常关闭控制台会先切回并确认原生 `ai`；若急停已锁存，则保留 gateway 的
  SAFE_DAMPING，不擅自恢复动力。
- Web 服务只监听 `127.0.0.1`，URL 含随机 token；它不是局域网远程控制接口。
