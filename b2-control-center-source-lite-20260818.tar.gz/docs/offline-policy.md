# Offline policy verification

This stage performs no DDS communication and cannot publish a robot command.

## Create the environment

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements/dev.txt
.venv/bin/python -m pip install --no-deps -e .
```

## Verify the handoff

```bash
.venv/bin/b2-verify-bundle /absolute/path/to/b2_policy_deployment_handoff
```

Success requires matching SHA-256 hashes, a float32 `45 -> 12` ONNX contract,
and the canonical hold inference. A failure blocks every later commissioning
stage.

For the current handoff on this workstation:

```bash
.venv/bin/b2-verify-bundle '/home/zhangchi/文档/xwechat_files/wxid_zyi9sp7uwkvz22_2442/msg/file/2026-08/b2_policy_deployment_handoff(1)/b2_policy_deployment_handoff'
```

Expected output:

```text
Bundle verified: hashes, float32 45 -> 12 contract, and golden inference match.
```

## Run tests

```bash
.venv/bin/python -m pytest -q
.venv/bin/python -m pytest --cov=b2_control --cov-report=term-missing -v
```
