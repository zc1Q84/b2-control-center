# B2 站立目标异常：代码提取、实验依据与根因定位

更新日期：2026-08-11  
仓库：`/home/zhangchi/b2_control_stack`  
状态：根因已定位，修复尚未实施；不得据此直接继续真机行走

## 1. 结论

当前后腿无力首先不是“某一个真机电机损坏”。

真机吊架测试和官方 B2 unitree_mujoco 都复现了相同的前后腿不对称。直接原因是当前 controller 在收到第一帧有效策略目标之前，把策略的 `Q_DEFAULT` 当成静态站立目标，并以 `Kp=160/Kd=5` 承重。

但实际 policy target 并不是 `Q_DEFAULT`，而是：

```text
q_policy_target = Q_DEFAULT + ACTION_SCALE * policy_action
```

`Q_DEFAULT` 是策略动作的参考偏置，不等同于经过策略闭环修正后的稳定站姿。当前接管顺序跳过了 `policy_action`，让机器人先用裸 `Q_DEFAULT` 承重，因此后腿 hip/calf 形成持续位置误差和大力矩。

需要修改的是接管状态机，而不是直接提高 Kp。

## 2. 实验结果

### 2.1 真机吊架纯站立

测试条件：

- 无 ONNX policy；
- 无 `vx/vy/wz`；
- 1 秒插值到裸 `Q_DEFAULT`；
- `Kp=160/Kd=5`；
- 结束后成功恢复原厂 `ai`；
- LowState CRC=0，invalid=0，motor lost=0。

稳定阶段逐腿最大值：

| Leg | 最大 `abs(q_target-q_actual)` | 最大 `abs(tau_est)` |
|---|---:|---:|
| FR | 0.174 rad | 27.7 |
| FL | 0.151 rad | 24.8 |
| RR | 0.575 rad | 91.8 |
| RL | 0.569 rad | 90.8 |

### 2.2 unitree_mujoco 10 秒纯站立

测试条件与 controller 相同；DDS domain 1、loopback，与真机隔离。总流程为 1 秒插值加 10 秒静态站立。

10 秒末逐关节误差：

| Joint | FR | FL | RR | RL |
|---|---:|---:|---:|---:|
| hip | 0.091 | 0.095 | 0.450 | 0.457 |
| thigh | 0.140 | 0.141 | 0.272 | 0.278 |
| calf | 0.226 | 0.226 | 0.500 | 0.494 |

10 秒末后腿主要反馈：

| Joint | Error (rad) | `abs(tau_est)` |
|---|---:|---:|
| RR hip | 0.450 | 72.0 |
| RR thigh | 0.272 | 43.6 |
| RR calf | 0.500 | 80.0 |
| RL hip | 0.457 | 73.1 |
| RL thigh | 0.278 | 44.4 |
| RL calf | 0.494 | 79.0 |

`Kp × error` 与 `tau_est` 基本一致，例如 `160 × 0.500 ≈ 80`。这说明 controller 正在持续追赶静态目标，不是日志计算错误。

完整仿真日志：

`logs/sim-stand-diagnostic-10s-20260811.log`

## 3. 当前实际控制链

```text
进程启动
  ↓
立即 ReleaseMode(ai)
  ↓
启动 LowState subscriber / LowCmd publisher
  ↓
捕获第一帧 LowState
  ↓
实测 q → 裸 Q_DEFAULT，插值 1 秒
  ↓
如果 policy command 尚未到达：
持续发布裸 Q_DEFAULT + Kp160/Kd5
  ↓
收到 policy command 后：
才开始发布 Q_DEFAULT + action scale × policy action
```

问题发生在 policy 接入之前。机器人已经被要求用裸 `Q_DEFAULT` 承重，策略闭环尚未获得控制权。

## 4. 相关代码提取

以下片段按当前工作树提取；行号会随之后修改发生变化。

### 4.1 `Q_DEFAULT` 和关节顺序

来源：`src/b2_control/policy_math.py:8`

```python
JOINT_NAMES = (
    "FR_hip_joint", "FR_thigh_joint", "FR_calf_joint",
    "FL_hip_joint", "FL_thigh_joint", "FL_calf_joint",
    "RR_hip_joint", "RR_thigh_joint", "RR_calf_joint",
    "RL_hip_joint", "RL_thigh_joint", "RL_calf_joint",
)

Q_DEFAULT = np.array(
    (
        -0.1, 0.8, -1.5,
         0.1, 0.8, -1.5,
        -0.1, 1.0, -1.5,
         0.1, 1.0, -1.5,
    ),
    dtype=np.float64,
)

ACTION_SCALE = np.array((0.125, 0.25, 0.25) * 4, dtype=np.float64)
```

C++ controller 中复制了相同目标：

来源：`gateway/b2_sim_gateway.cpp:44`

```cpp
constexpr float kActiveKp = 160.0F;
constexpr float kActiveKd = 5.0F;
constexpr auto kInitialInterpolation = std::chrono::seconds(1);

constexpr std::array<float, kJoints> kDefaultPose{
    -0.1F, 0.8F, -1.5F, 0.1F, 0.8F, -1.5F,
    -0.1F, 1.0F, -1.5F, 0.1F, 1.0F, -1.5F};
```

关节顺序与 B2 MuJoCo actuator/sensor 顺序一致，因此现有证据不支持“整个后腿槽位映射错位”。

### 4.2 真正的 policy target 包含 action

来源：`src/b2_control/policy_math.py:156`

```python
def joint_targets(action: Any) -> np.ndarray:
    return Q_DEFAULT + ACTION_SCALE * _vector(action, ACTION_DIM, "action")
```

来源：`src/b2_control/core.py:56`

```python
observation = build_observation(
    omega_body=omega_body_rad_s,
    rotation_body_to_world=rotation_body_to_world,
    command=command,
    q=joint_position_rad,
    dq=joint_velocity_rad_s,
    previous_action=self.previous_action,
)
action = np.asarray(self.policy.infer(observation), dtype=np.float32)
desired = joint_targets(action)
self.previous_action[:] = action
```

因此 `hold=True` 仅把速度命令设为零，仍然会执行 ONNX：

来源：`src/b2_control/policy_math.py:143` 和 `src/b2_control/cli_sim_policy.py:110`

```python
if hold:
    command = np.zeros(3, dtype=np.float32)

output = core.step(
    # LowState fields omitted
    nominal_speed_m_s=args.speed,
    hold=args.hold or settling,
)
```

“learned-hold”不是“action=0”，也不是“直接发送 Q_DEFAULT”。

### 4.3 当前 controller 强制插值到裸 `Q_DEFAULT`

来源：`gateway/b2_sim_gateway.cpp:350`

```cpp
void begin_interpolation(
    const unitree_go::msg::dds_::LowState_ &state, Clock::time_point now) {
  interpolation_started_ = true;
  interpolation_started_at_ = now;
  for (std::size_t i = 0; i < kJoints; ++i) {
    interpolation_start_[i] = state.motor_state()[i].q();
    last_target_[i] = interpolation_start_[i];
  }
}

std::array<float, kJoints> interpolation_target(
    Clock::time_point now) const {
  const float elapsed =
      std::chrono::duration<float>(now - interpolation_started_at_).count();
  const float alpha = std::clamp(elapsed, 0.0F, 1.0F);
  std::array<float, kJoints> target{};
  for (std::size_t i = 0; i < kJoints; ++i)
    target[i] = interpolation_start_[i] +
                alpha * (kDefaultPose[i] - interpolation_start_[i]);
  return target;
}
```

### 4.4 没有 policy command 时继续发布裸 `Q_DEFAULT`

来源：`gateway/b2_sim_gateway.cpp:409`

```cpp
if (fault_latched_.load()) {
  set_damping();
  mode_ = "SAFE_DAMPING";
} else if (now - interpolation_started_at_ < kInitialInterpolation) {
  set_position_target(interpolation_target(now));
  mode_ = "INTERPOLATE";
} else if (!have_command_) {
  set_position_target(kDefaultPose);
  mode_ = "STAND_WAITING_POLICY";
} else if (now - command_received_at_ <= kCommandTimeout) {
  set_position_target(limited_policy_target());
  policy_ever_active_ = true;
  mode_ = "POLICY";
}
```

这段代码就是10秒站立仿真的直接入口。

### 4.5 LowCmd 使用静态目标和仿真匹配增益

来源：`gateway/b2_sim_gateway.cpp:337`

```cpp
void set_position_target(const std::array<float, kJoints> &target) {
  for (std::size_t i = 0; i < kJoints; ++i) {
    auto &motor = low_command_.motor_cmd()[i];
    motor.mode() = kB2ServoMode;
    motor.q() = target[i];
    motor.dq() = 0.0F;
    motor.kp() = kActiveKp;
    motor.kd() = kActiveKd;
    motor.tau() = 0.0F;
    last_target_[i] = target[i];
  }
}
```

### 4.6 MuJoCo 对 LowCmd 的执行公式

来源：`third_party/unitree_mujoco/simulate/src/unitree_sdk2_bridge.h:178`

```cpp
mj_data_->ctrl[i] =
    m.tau() +
    m.kp() * (m.q() - mj_data_->sensordata[i]) +
    m.kd() * (m.dq() - mj_data_->sensordata[i + num_motor_]);
```

反馈：

```cpp
lowstate->msg_.motor_state()[i].q() =
    mj_data_->sensordata[i];
lowstate->msg_.motor_state()[i].dq() =
    mj_data_->sensordata[i + num_motor_];
lowstate->msg_.motor_state()[i].tau_est() =
    mj_data_->sensordata[i + 2 * num_motor_];
```

所以仿真中的 `tau_est` 是 MuJoCo joint actuator force。温度和 motor lost 没有在 bridge 中填充，仿真中保持零，不能和真机温度/通信故障横向比较。

### 4.7 当前逐关节诊断代码

来源：`gateway/b2_sim_gateway.cpp:455`

```cpp
tracking_error[leg] =
    std::max(tracking_error[leg],
             std::fabs(last_target_[i] - state.motor_state()[i].q()));

const float tau = state.motor_state()[i].tau_est();
if (std::isfinite(tau))
  absolute_tau[leg] =
      std::max(absolute_tau[leg], std::fabs(tau));
```

逐关节输出：

```cpp
std::cout << " " << kJointNames[i]
          << "={target:" << last_target_[i]
          << ",actual:" << motor.q()
          << ",error:" << last_target_[i] - motor.q()
          << ",dq:" << motor.dq()
          << ",tau:" << motor.tau_est()
          << ",temp:" << static_cast<unsigned int>(motor.temperature())
          << ",lost:" << motor.lost() << "}";
```

### 4.8 官方 B2 example 是另一组站姿流程

来源：`third_party/unitree_sdk2/example/b2/b2_stand_example.cpp:61`

```cpp
float _targetPos_1[12] = {
    0.0, 1.36, -2.65, 0.0, 1.36, -2.65,
    0.2, 1.36, -2.65, 0.2, 1.36, -2.65};

float _targetPos_2[12] = {
    0.0, 0.67, -1.3, 0.0, 0.67, -1.3,
    0.0, 0.67, -1.3, 0.0, 0.67, -1.3};
```

官方 example 从实测位置分阶段插值到多组目标，使用 `Kp=1000/Kd=10`。这说明：

- 官方 example 没有把策略 `Q_DEFAULT` 当作唯一静态站姿；
- 官方示例的姿态、阶段和增益是一套整体流程；
- 不能只复制 `Kp=1000/Kd=10` 到当前 `Q_DEFAULT`；
- 该 example 还提示机器人应躺地运行，不能直接当作本项目的承重部署参数。

## 5. 根因推导

### 5.1 排除项

1. **不是单个后腿电机失联**：两侧后腿高度对称，真机 lost=0、CRC=0。
2. **不是单纯真机机械故障**：unitree_mujoco 用相同 controller 复现相同趋势。
3. **不是整个关节顺序错误**：policy、LowCmd、MuJoCo actuator 和 sensor 都采用 FR/FL/RR/RL × hip/thigh/calf。
4. **不是 ONNX 推理慢**：当前纯站立测试根本没有运行 ONNX。

### 5.2 已确认的软件问题

当前 controller 把两个不同概念混在一起：

- 策略参考偏置 `Q_DEFAULT`；
- 策略闭环产生的 learned-hold 目标。

正确 learned-hold 目标必须经过 observation → ONNX → action → target。裸 `Q_DEFAULT` 没有 policy action 修正，10秒仿真证明它不能在当前设置下稳定承重。

### 5.3 仍需验证的次级问题

修复接管顺序后仍需验证：

- 第一帧 learned-hold target 是否适合真机当前姿态；
- action history 初始为零时的首帧瞬态；
- 当前实测 q 到首帧 policy target 的逐关节差；
- 目标插值过程中是否应冻结、重算或持续运行 policy；
- 真实后腿电机、供电和机械状态；
- 真机 Kp/Kd 与限制参数。

## 6. 建议状态机

### 6.1 当前错误状态机

```text
RELEASE_AI
→ WAIT_LOWSTATE
→ INTERPOLATE_TO_Q_DEFAULT
→ STAND_WAITING_POLICY(Q_DEFAULT)
→ POLICY
```

### 6.2 建议状态机

```text
NATIVE_AI_READ_ONLY
→ 收集有效 LowState
→ 启动 learned-hold policy shadow
→ 收到连续、有限、未超时的首批 policy target
→ 校验 target 与当前 q 的差值/限幅
→ 现场允许后 ReleaseMode(ai)
→ 从接管瞬间 q 平滑插值到 learned-hold target
→ POLICY_HOLD
→ 才允许非零 vx/vy/wz
```

核心原则：

1. 原厂 `ai` 未释放时，只订阅 LowState，不发布 LowCmd。
2. 在首帧有效 policy target 到达之前，不进入自研低层承重。
3. 接管插值终点必须是 learned-hold policy target，不是裸 `Q_DEFAULT`。
4. 插值期间 policy target 的更新方式必须明确，不能无界跳变。
5. 非零速度命令必须在 learned-hold 承重稳定后单独解锁。
6. 正常 policy 结束保持最后安全目标；真实 state/CRC/NaN 故障才进入锁存阻尼。
7. controller 退出和恢复原厂 `ai` 必须继续在吊架下验证。

## 7. 建议代码改动位置

| 文件 | 修改 |
|---|---|
| `gateway/b2_sim_gateway.cpp` | 把 MotionSwitcher ReleaseMode 从 `main` 启动前移入“首批 policy target 已就绪”状态 |
| `gateway/b2_sim_gateway.cpp` | 删除启动阶段 `INTERPOLATE_TO_Q_DEFAULT` 和 `STAND_WAITING_POLICY(Q_DEFAULT)` |
| `gateway/b2_sim_gateway.cpp` | 新增 `WAIT_FIRST_POLICY`、`READY_TO_HANDOVER`、`INTERPOLATE_TO_POLICY` |
| `src/b2_control/cli_sim_policy.py` | controller 接管前先持续运行 learned-hold shadow |
| `src/b2_control/core.py` | 明确 reset 后首帧 previous_action=0 的诊断记录 |
| tests | 增加“没有 policy command 时绝不发布 active LowCmd”的状态机测试 |
| tests | 增加“插值终点等于首帧 policy target，不等于 Q_DEFAULT”的测试 |
| tests | 增加 policy stale、NaN 和退出时的 SAFE_HOLD/SAFE_DAMPING 分流测试 |

## 8. 验收顺序

1. unit test 验证未收到 policy 时不会释放原厂模式或发布 active LowCmd。
2. unitree_mujoco：10秒 learned-hold，确认不再出现裸 `Q_DEFAULT` 静态站立。
3. unitree_mujoco：比较12关节 target/actual/error/tau。
4. unitree_mujoco：policy 停止后持续 SAFE_HOLD，controller 正常退出不发送 Kp=0。
5. 真机只读 learned-hold shadow，检查首帧 target 与当前 q 差值。
6. 吊架下零速度 learned-hold 接管。
7. 只有 learned-hold 承重稳定后，才允许短时 `vx=0.25 m/s`。

## 9. 负责人摘要

真机后腿无力不是当前能够确认的电机故障。相同 controller 在 MuJoCo 中复现了后腿 hip/calf 的大跟踪误差。

根因是接管状态机在 policy target 尚未就绪时，先释放原厂 `ai`，再把策略参考偏置 `Q_DEFAULT` 当作静态站姿承重。真正 learned-hold 目标应包含 ONNX action 修正。

下一步应修改接管时序：先在原厂模式下完成 LowState 和 learned-hold policy shadow，首批目标通过门禁后再释放 `ai`，并从接管瞬间实测 q 平滑插值到 policy target。禁止通过直接提高 Kp 掩盖该问题。
