# B2 parameter research

Status: reference only; not a hardware-control approval profile  
Checked: 2026-08-11

The machine-readable counterpart is
[`../configs/b2-reference-profile.json`](../configs/b2-reference-profile.json).
It deliberately sets `activation_permitted` to `false`; the runtime validator
reports every hardware-owner field that is still missing.

This note separates public Unitree values, policy-training values, and values
that are still hardware-owner decisions. A number appearing in an official
demo or simulator model is not automatically a safe real-robot deployment
limit.

## Public Unitree values

| Item | Published value | Source meaning | Deployment use |
|---|---:|---|---|
| Real-robot DDS domain | `0` | B2 SDK example initializes domain 0 | Read-only probes already use it |
| Low-level topics | `rt/lowcmd`, `rt/lowstate` | B2 SDK example topic names | State topic is verified; command topic remains hardware-owned |
| Example low-command period | `2 ms` (`500 Hz`) | B2 stand example recurrent thread; source comments allow `1..10 ms` | Timing reference, not a watchdog threshold |
| Example motor mode | `0x0A` | Servo/PMSM mode in B2 stand example | Reference only; enable sequence remains hardware-owned |
| Example full-body gains | `Kp=1000`, `Kd=10` | Gains for the official pre-scripted B2 stand example | **Do not apply to the learned policy** |
| Example upright waypoint | hip `0`, thigh `0.67`, calf `-1.30 rad` | One waypoint in the official stand trajectory | Comparison only; it is not this actor's default posture |
| Example interpolation counts | `500, 900, 1000, 1100, 500` ticks | At 2 ms: `1.0, 1.8, 2.0, 2.2, 1.0 s` phases | Evidence that the demo interpolates posture; not an approved policy slew limit |
| Model hip range | `[-0.87, 0.87] rad` | Official B2 MuJoCo joint range | Model-range validation only |
| Model thigh range | `[-0.94, 4.69] rad` | Official B2 MuJoCo joint range | Model-range validation only |
| Model calf range | `[-2.82, -0.43] rad` | Official B2 MuJoCo joint range | Model-range validation only |
| Model actuator ctrlrange | hip/thigh `+-200`, calf `+-300` | MuJoCo actuator control ranges | Simulator values, not firmware torque/current approval |
| Product max joint torque | about `360 N.m` | Product-level maximum, without a per-joint command-limit table | Must not be used as a command limit |
| Product operating temperature | `-20..55 degC` | Robot operating-environment specification | Not a motor-temperature trip threshold |
| Product battery | `58 V`, `45 Ah`, `2250 Wh` | Product specification | Telemetry plausibility reference only |

The SDK source used here is the pinned project revision
[`21d0a3b`](https://github.com/unitreerobotics/unitree_sdk2/blob/21d0a3b2c46ee48c8fdf2783becb6be3beb0a59b/example/b2/b2_stand_example.cpp).
It explicitly warns that the robot must be lying on the ground before running
its stand sequence. The model values come from the pinned official
[`b2.xml`](https://github.com/unitreerobotics/unitree_mujoco/blob/ae6a8403e272733e9996ef59990880330496177f/unitree_robots/b2/b2.xml).
Product specifications come from the official
[`B2 product page`](https://www.unitree.com/b2/).

## Supplied policy values

These values come from `b2_policy_deployment_handoff(1)`, not from Unitree's
hardware manual.

| Item | Supplied value | Correct use |
|---|---:|---|
| Policy frequency | `50 Hz` | Actor inference and candidate-target generation |
| Training PD gains | all 12 legs `Kp=160`, `Kd=5` | Simulator reproduction; candidate for engineer review, not automatic real enable |
| Training velocity limit | hip/thigh `23`, calf `14 rad/s` | Simulator physical limit, not handover slew rate |
| Training effort limit | hip/thigh `200`, calf `320` | Simulator setting; note calf differs from official MuJoCo `300` |
| Action scale | hip `0.125`, thigh/calf `0.25 rad` | Exact actor-output transform |
| Default posture | FR/FL thighs `0.8`, RR/RL thighs `1.0`, calves `-1.5 rad`, hips `+-0.1 rad` | Exact observation/target contract |
| Supported forward command | `0.25..1.0 m/s` | First moving trial starts at `0.25 m/s` |
| Hold command | `[0,0,0]` | Learned hold only; never an emergency fallback |

The current official B2 URDF independently lists hip/thigh effort `200` and
velocity `23 rad/s`, and calf effort `320` and velocity `14 rad/s`.
[`b2_description.urdf`](https://github.com/unitreerobotics/unitree_ros/blob/master/robots/b2_description/urdf/b2_description.urdf)
These match the supplied training configuration, but remain model ceilings:
they are not target slew rates or approved runtime torque limits.

The machine-readable profile now pre-fills an
`engineering_review_candidates` section with `Kp=160`, `Kd=5`, the URDF model
ceilings, and the official example's `2 ms` command period. Each candidate is
explicitly marked as not approved for its corresponding real-hardware use.

The real standing dry-run produced a maximum current-to-candidate-target step
of `0.388 rad` for learned hold and `0.377 rad` at `0.25 m/s`. Therefore even
the correct policy contract still needs a reviewed continuity/ramp procedure
before any actuator publication.

## Parameters not published as safe deployment defaults

The public B2 SDK example, B2 model, product page, and accessible B2 developer
index do not specify the following as certified learned-policy deployment
values:

- per-joint target slew/rate during native-to-custom handover;
- learned-policy real-hardware `Kp/Kd` and gain ramp time;
- per-joint soft-limit margins;
- per-motor temperature trip and reset thresholds;
- body tilt and angular-rate trip thresholds;
- state, policy, command, publisher, and recovery timeouts;
- per-joint torque/current limits for this controller;
- the complete validated `ReleaseMode -> custom -> native ai_sport` handover
  timing and failure fallback.

These fields remain required in the signed hardware approval profile. Leaving
them absent must keep hardware control unavailable. In particular, neither
`Kp=1000/Kd=10` from the scripted stand example nor `Kp=160/Kd=5` from training
is treated as a safe real-robot default.

The Unitree developer index used for the search is the official
[`B2 SDK Development Guide`](https://support.unitree.com/home/en/B2_developer).

## Engineering review command

Run the checker after editing a copy of the reference profile:

```bash
env PYTHONPATH=src \
  .worktrees/offline-policy-foundation/.venv/bin/python \
  -m b2_control.cli_check_parameters configs/b2-reference-profile.json
```

The checked-in reference profile intentionally returns exit code `2` and lists
every missing approval value. A completed profile returns `0` only when its
status is `approved`, `activation_permitted` is exactly `true`, every required
value is present, all per-joint fields are positive finite 12-vectors, and the
temperature trip exceeds its reset threshold. This command performs no DDS
communication and cannot publish a motor command.
